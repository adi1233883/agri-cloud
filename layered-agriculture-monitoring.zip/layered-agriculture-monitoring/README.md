# 🌱 AgriLayer — Layered Agriculture Monitoring System

A cloud-connected web platform that monitors a farm divided into **layers (zones)** — vegetables, fruit, grains and a greenhouse — using IoT-style sensor data, a cloud database, data analytics, alerts and a modern dashboard.

> **Sensors → Backend API → Cloud database → Data processing → Analytics → Dashboard → Alerts → Decisions**

Works in two modes with the same code:

| Mode | When | Database | Login |
|---|---|---|---|
| **Demo (offline)** | No Supabase variables set | In-memory (seeded with 30 days of data) | Built-in demo accounts |
| **Cloud** | `SUPABASE_*` variables set | Supabase PostgreSQL | Supabase Auth |

---

## 1. Project overview
Farmers manage several crop areas with different needs. AgriLayer gives them one dashboard showing the live condition of every layer, historical trends, comparisons, correlations, automatic insights and threshold alerts. Sensor data is **simulated realistically** (gradual, weather- and time-of-day-driven changes), and the system is built so real IoT sensors can replace the simulator (see [docs/CONCEPTS.md](docs/CONCEPTS.md)).

## 2. Problem statement
Farm data is usually scattered, manual and local. Managers notice dry soil, heat stress or a falling pH late, and cannot compare zones or see what changed over time. There is no central, always-available view and no automatic warning.

## 3. Objectives
1. Collect sensor data from multiple farm layers into **one cloud database**.
2. Process the data into **descriptive, trend, comparative and correlation analytics**.
3. Generate **alerts and plain-language recommendations** from real values.
4. Present everything in a **responsive dashboard** with role-based access (Admin / Viewer).
5. Be **deployable to the cloud** (Vercel + Render + Supabase) and scalable to more farms/sensors.

## 4. Features
- Dashboard with 6 KPI cards (value, unit, % change vs. yesterday, sparkline), layer snapshot, alerts, 24 h charts, insights
- **Farm Layers** page and per-layer detail (sensors vs. the crop's preferred range, charts, alerts, irrigation, health)
- **Live Monitoring** (updates every 4 s, 🟢 Live Data badge, pause/resume, Supabase Realtime when configured)
- **Analytics**: descriptive stats, trends (Today / 7 d / 30 d), layer comparison (line / area / bar), correlation matrix, auto-insights
- **Alerts**: threshold rules with Critical / Warning / Informational severity; admins mark resolved; alerts auto-clear on recovery
- **Irrigation**: water used today/week/month, layer-wise consumption, *simulated* Start/Stop control
- **Crop Health**: score ring, disease risk, growth status, last inspection, 30-day history
- **Reports** (layer + range + metrics → summary + recommendations) and **CSV export**
- Supabase Auth (login / signup / logout), roles, loading / error / empty states, mobile-first responsive UI

## 5. Technology stack
| Layer | Technology |
|---|---|
| Frontend | React 18, Vite, Tailwind CSS, Recharts, Lucide icons, React Router |
| Backend | Node.js, Express (REST API), sensor simulator |
| Cloud | Supabase (PostgreSQL, Auth, Realtime), Render/Railway (API), Vercel (frontend) |
| Testing | Vitest + Testing Library (page smoke tests against the live API) |

## 6. System architecture
```mermaid
flowchart TD
  S["Sensors / Simulated sensors"] --> C["Data collection (simulator or POST /api/readings/ingest)"]
  C --> B["Backend API — Node + Express (Render)"]
  B --> D[("Cloud database — Supabase PostgreSQL")]
  D --> P["Data processing (bucketing, aggregation)"]
  P --> A["Analytics (descriptive, trends, comparison, correlation, insights)"]
  A --> W["Web dashboard — React (Vercel)"]
  B --> L["Alert engine (threshold rules)"]
  L --> D
  L --> W
  W --> R["Alerts and recommendations → farm decisions"]
  U["Supabase Auth (JWT)"] -. verifies .-> B
  U -. login .-> W
  D -. Realtime .-> W
```
Cloud services involved: **Vercel** (static hosting + CDN), **Render** (always-on API + simulator), **Supabase** (database, authentication, realtime).

## 7. Database architecture
Relational PostgreSQL with foreign keys, CHECK constraints, indexes and Row Level Security. Full DDL: [`database/schema.sql`](database/schema.sql).

```
users ──< farms ──< layers ──< sensors ──< sensor_readings
                       ├────< alerts
                       ├────< irrigation
                       └────< crop_health
```
| Table | Key columns |
|---|---|
| users | id (= auth.users.id), name, email, role (`admin`/`viewer`), created_at |
| farms | id, farm_name, location, total_area, owner_id → users |
| layers | id, farm_id → farms, layer_name, crop_type, area, status |
| sensors | id, layer_id → layers, sensor_type, sensor_name, unit, status |
| sensor_readings | id, sensor_id → sensors, value, timestamp |
| alerts | id, layer_id, alert_type, message, severity, status, timestamp, resolved_at |
| irrigation | id, layer_id, water_used (L), duration (min), status, timestamp |
| crop_health | id, layer_id, health_score, disease_risk, growth_status, timestamp |

**Seed data** ([`database/seed.sql`](database/seed.sql)): 1 farm, 4 layers (Tomato, Papaya, Wheat, Bell Pepper), 28 sensors, ~5,000 readings (30 days), 30+ alerts, 34 irrigation records, 120+ crop-health records.

## 8. Cloud computing implementation
- **Cloud database** — all readings, alerts, irrigation and health records live in Supabase PostgreSQL, not on the user's machine.
- **Cloud API** — the Express backend is deployed on Render; the dashboard talks to it over HTTPS.
- **Cloud authentication** — Supabase Auth issues JWTs; the API verifies every request with `supabase.auth.getUser(token)`; roles come from the `users` table.
- **Real-time updates** — the dashboard subscribes to Supabase Realtime (`sensor_readings` inserts) and also polls as a fallback.
- **Centralised data** — every device, user and browser reads the same data.
- **Scalability** — stateless API (scale horizontally), indexed time-series tables, 1000-row paging, 45-day retention cleanup. Adding a farm/layer/sensor is a row insert, not a code change.
- **Security** — secrets only in environment variables; service-role key stays on the server; RLS lets signed-in users *read* but only the API *write*; roles can't be self-assigned.

## 9. Data analytics implementation
All analytics run on the backend ([`backend/services/`](backend/services)) on real database rows:
1. **Collection** — simulator/devices insert readings; irrigation, health and alerts are stored too.
2. **Cleaning** — values are clamped to physical ranges; readings are bucketed (hourly / 6-hourly / daily) and averaged; missing crop-health buckets carry the last inspection forward.
3. **Descriptive** — mean, max, min, totals, counts (`describe()`), plus % change vs. the previous period.
4. **Trends** — per-layer and farm series per metric for Today (hourly), 7 d (6-hourly), 30 d (daily).
5. **Comparative** — averages per layer and time-series overlays.
6. **Correlation** — Pearson *r* on daily per-layer values (30 days): soil moisture, temperature, water usage vs. crop health + a full matrix. The UI states that **correlation ≠ causation**.
7. **Insights** — rules over computed values (moisture vs. farm average, 7-day temperature change, out-of-range temperature/pH, health decline, disease risk, irrigation need).

## 10. API documentation
Base URL: `/api`. All routes except those marked *public* need `Authorization: Bearer <token>`. Most accept `?farm_id=` (default: first farm). `range` is `today | 7d | 30d`. Errors return `{ "error": "message" }` with 400/401/403/404/409/502.

| Method & path | Role | Description |
|---|---|---|
| GET `/health` | public | Health check |
| GET `/auth/mode`, `/auth/demo-credentials` | public | Mode info; demo logins (demo mode only) |
| POST `/auth/login` | public | Demo-mode login → `{ token, user }` |
| GET `/auth/me` | any | Current user and role |
| GET `/farms` | any | List farms |
| GET `/layers`, `/layers/:id` | any | Layers with live values, condition, health / full detail |
| POST `/layers` | admin | `{ layer_name, crop_type, area }` |
| GET `/sensors` · POST `/sensors` | any · admin | List · `{ layer_id, sensor_type, sensor_name? }` |
| GET `/crops` | any | Crops with preferred ranges |
| GET `/live` | any | Latest value per sensor type per layer |
| GET `/readings?limit=` · `/readings/:layerId?range=` | any | Raw readings |
| POST `/readings/ingest` | device key | Real IoT device posts `{ sensor_id, value }` with `X-Device-Key` |
| GET `/dashboard/stats` | any | KPIs, layers, alerts, insights, 24 h trends |
| GET `/analytics?range=` · `/analytics/:layerId` | any | Summary + trends + comparison + correlation + insights |
| GET `/analytics/summary` `/trends` `/comparison` `/correlation` `/insights` | any | Individual analytics |
| GET `/alerts?status=&severity=` | any | List alerts |
| POST `/alerts/:id/resolve` | admin | Mark resolved |
| GET `/irrigation` | any | Totals, per-layer status, chart data, recent events |
| POST `/irrigation/start` · `/irrigation/stop` | admin | `{ layer_id }` — **simulated** |
| GET `/crop-health` | any | Score, disease risk, growth, last inspection, history |
| GET `/reports?layer_id=&range=&metrics=` | any | Report summary + recommendations |
| GET `/export/csv?layer_id=&range=` | any | CSV: Timestamp, Layer, Temperature, Humidity, Soil Moisture, pH, Water Usage, Crop Health |

Example — `GET /api/analytics/summary?range=today`
```json
{ "averageTemperature": 27.3, "averageHumidity": 66.2, "averageSoilMoisture": 44.1,
  "totalWaterUsage": 2240, "averageCropHealth": 91.4, "activeAlerts": 2,
  "change": { "averageTemperature": -0.4 } }
```

## 11. Installation
Requirements: **Node.js 18+**.
```bash
cd backend  && npm install
cd ../frontend && npm install
```

## 12. Environment variables
Templates: [`backend/.env.example`](backend/.env.example) and [`frontend/.env.example`](frontend/.env.example). Never commit real `.env` files.

| Variable | Where | Purpose |
|---|---|---|
| `SUPABASE_URL` | backend | Supabase project URL |
| `SUPABASE_ANON_KEY` | backend + frontend (`VITE_SUPABASE_ANON_KEY`) | Public key (safe in browsers; protected by RLS) |
| `SUPABASE_SERVICE_ROLE_KEY` | **backend only** | Lets the API write data. **Secret** |
| `DATABASE_URL` | backend (migration script) | Postgres connection string |
| `API_URL` / `VITE_API_URL` | frontend | Public URL of the backend (`https://…/api`) |
| `CORS_ORIGIN` | backend | Allowed frontend origin(s) |
| `SIMULATOR_ENABLED`, `SIM_TICK_MS`, `SIM_PERSIST_EVERY` | backend | Simulator controls |
| `DEVICE_API_KEY` | backend | Enables `/readings/ingest` for real devices |

## 13. Running locally
**A. Demo mode (fastest — no accounts needed)**
```bash
# terminal 1
cd backend && npm start          # http://localhost:4000
# terminal 2
cd frontend && npm run dev       # http://localhost:5173
```
Log in with **admin@agri.demo / Admin@123** (admin) or **viewer@agri.demo / Viewer@123** (viewer).

**B. Cloud mode (Supabase)** — do [§14 step 1](#14-deployment) first, then:
```bash
cd backend
cp .env.example .env     # fill SUPABASE_URL, keys, DATABASE_URL
npm run migrate          # creates tables + loads seed data
npm run demo-users       # creates the two demo accounts in Supabase Auth
npm start
cd ../frontend && cp .env.example .env   # fill VITE_SUPABASE_URL + VITE_SUPABASE_ANON_KEY
npm run dev
```
**Tests:** with the backend running, `cd frontend && npm test` renders every page against the live API.

## 14. Deployment
### Step 1 — Supabase (database + auth)
1. https://supabase.com → **New project** (choose a region near your users, save the DB password).
2. **Project Settings → API**: copy *Project URL*, *anon public* key and *service_role* key.
3. **Project Settings → Database → Connection string → URI** (use the **Session pooler** string if direct connections fail on IPv4). Put the password in it.
4. Put those values in `backend/.env`, then run `npm run migrate` (applies `schema.sql` + `seed.sql`).
   *Alternative:* paste `database/schema.sql`, then `database/seed.sql` into **SQL Editor → Run**.
5. Create accounts: `npm run demo-users`. Or sign up in the app, then in SQL Editor run
   `update public.users set role = 'admin' where email = 'you@example.com';`
6. Optional for demos: **Authentication → Providers → Email → turn off "Confirm email"**.

> The seed contains 30 days ending when the file was generated. For a fresh timeline run `npm run seed:sql && npm run migrate` right before presenting.

### Step 2 — Backend on Render (Railway works the same way)
1. Push this repo to GitHub.
2. Render → **New → Web Service** → pick the repo. **Root Directory:** `backend`, **Build:** `npm install`, **Start:** `npm start`, health check `/api/health`. (Or use the included `render.yaml` Blueprint.)
3. Environment: `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `CORS_ORIGIN` (fill after step 3), `SIMULATOR_ENABLED=true`.
4. Deploy → note the URL, e.g. `https://agri-api.onrender.com`. Check `…/api/health`.
> Free Render services sleep when idle, which pauses the simulator. Ping `/api/health` every 5 minutes (e.g. UptimeRobot) or use a paid instance during demos.

### Step 3 — Frontend on Vercel
1. Vercel → **Add New → Project** → import the repo. **Root Directory:** `frontend`, framework **Vite**.
2. Environment variables: `VITE_API_URL=https://agri-api.onrender.com/api`, `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`.
3. Deploy. (`frontend/vercel.json` makes React Router deep links work.)
4. Go back to Render and set `CORS_ORIGIN=https://<your-app>.vercel.app`, then redeploy the API.

## 15. Future scope
Real IoT hardware (ESP32 + LoRa/MQTT) posting to `/api/readings/ingest`; weather-forecast-aware irrigation; ML disease/yield prediction; SMS / WhatsApp / push alerts; real valve control with safety interlocks; multi-farm tenancy per owner; satellite/NDVI layers; PDF reports; offline-first mobile app; time-series partitioning (TimescaleDB) for very large data.

---
## Project structure
```
layered-agriculture-monitoring/
├── backend/
│   ├── server.js            # Express app + simulator start
│   ├── config/              # env config, crop profiles, alert rules, health scoring
│   ├── db/                  # repository: Supabase + in-memory, seed generator
│   ├── middleware/          # auth (Supabase JWT / demo), farm scope, errors
│   ├── routes/ controllers/ services/ models/
│   ├── simulator/           # realistic sensor physics + runner
│   └── scripts/             # migrate, seed:sql, demo-users
├── frontend/src/
│   ├── pages/ components/ charts/ hooks/ services/ context/ utils/
│   └── __tests__/           # page smoke tests
├── database/                # schema.sql, seed.sql
├── docs/CONCEPTS.md         # cloud, analytics and IoT explained for the report
├── render.yaml  .gitignore
└── README.md
```
## Notes on honesty
Irrigation control and sensor data are **simulated**; no hardware is controlled. Crop-health score and insights are rule-based estimates from the simulated readings, not agronomic advice.
