# Concepts explained (for the college report)

## 1. Cloud computing
**What it is:** using computers, storage and software that live on the internet (run by a provider) instead of on your own machine.

| Idea | Why it matters in this project |
|---|---|
| **Cloud storage / database** | Sensor readings, alerts and irrigation history are saved in Supabase's PostgreSQL. They survive if a laptop breaks, and nothing is lost when the browser closes. |
| **Why a cloud *database*** | It is managed (backups, security patches, uptime) and supports many users and devices at once through APIs. Students do not need to run a database server. |
| **Scalability** | More sensors, layers or farms only mean more rows; the API is stateless so more copies can run behind a load balancer, and the provider can give the database more resources. |
| **Centralised access** | The farm manager, an agronomist and a viewer can all open the same dashboard from any device and see the same data. |
| **Real-time data** | New readings are stored in the cloud and pushed to the dashboard (Supabase Realtime), so the screen updates without reloading. |
| **Cloud authentication** | Supabase Auth handles passwords and issues tokens; the API verifies each request, and roles (Admin / Viewer) limit what each person can do. |

**Deployment model used:** Frontend on Vercel (static hosting + CDN), backend on Render (always-on service), data and auth on Supabase — a typical *Platform-as-a-Service (PaaS)* + *Backend-as-a-Service (BaaS)* combination.

## 2. Data analytics
1. **Data collection** — sensors (simulated here) measure temperature, humidity, soil moisture, pH, light, tank level, CO₂ and rainfall at regular intervals; each reading is stored with a timestamp.
2. **Data cleaning** — readings are limited to physically possible ranges, noisy values are averaged into time buckets (hour / 6 hours / day), and gaps (e.g. crop health recorded once per day) are filled by carrying the last known value forward.
3. **Descriptive analytics** — *what happened?* Mean, maximum, minimum, totals and counts, plus % change against the previous period.
4. **Trend analysis** — *how is it changing?* Values plotted over time for Today, 7 days and 30 days to spot drying soil or rising heat.
5. **Comparative analysis** — *which layer is different?* Layers are compared on the same metrics (line, area and bar charts).
6. **Correlation analysis** — *do two measurements move together?* The Pearson coefficient *r* ranges from −1 to +1. Example: r = +0.72 between soil moisture and crop health means higher moisture tends to go with better health. **Correlation does not prove causation** — other factors (e.g. temperature) may drive both.
7. **Data visualisation** — KPI cards, line/area/bar charts, a colour-coded correlation matrix and status badges turn numbers into something a farmer can read at a glance.
8. **Insights and decision-making** — rules over the calculated numbers produce messages such as "Layer 2 has 18% lower soil moisture than the farm average — irrigation recommended". Alerts fire when thresholds are crossed. Farmers act on these (irrigate, ventilate, adjust pH).

## 3. IoT concept — replacing the simulator with real sensors
In a real deployment each layer would have physical sensors:

| Measurement | Example hardware |
|---|---|
| Temperature & humidity | DHT22 / SHT31 |
| Soil moisture | Capacitive soil-moisture probe |
| Soil pH | Analog pH probe + interface board |
| Light | BH1750 / LDR |
| Tank level | Ultrasonic JSN-SR04T or float switch |
| CO₂ | MH-Z19 / SCD41 |
| Rainfall | Tipping-bucket rain gauge |

A microcontroller (ESP32) reads the sensors and sends data over Wi-Fi/LoRa. It would `POST` JSON to the API:
```http
POST /api/readings/ingest
X-Device-Key: <secret from DEVICE_API_KEY>
Content-Type: application/json

{ "sensor_id": 3, "value": 41.7 }
```
The backend stores the reading, runs the alert rules and the dashboard shows it like any other data. Then set `SIMULATOR_ENABLED=false`. Nothing else in the analytics, alerts or UI changes — the simulator is simply a stand-in data source. Real irrigation would additionally need a relay/solenoid valve controlled by the ESP32, with safety limits (maximum run time, tank-empty cut-off).
