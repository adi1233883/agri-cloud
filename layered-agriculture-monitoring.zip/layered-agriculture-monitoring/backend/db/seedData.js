// Generates 30 days of realistic history by running the same simulator model used live.
import {
  FARM, LAYER_DEFS, layerSensorTypes, SENSOR_META, evaluateRules,
  scoreHealth, diseaseRisk, growthStatus, flowRate,
} from '../config/agri.js';
import { Weather, initialState, stepLayer, applyIrrigation, refillIfEmpty, reading, setRng, mulberry32, random } from '../simulator/model.js';

export function generateSeed(now = new Date(), seed = 20260101) {
  setRng(mulberry32(seed));
  const DAYS = 30;
  const HOURS = DAYS * 24;
  const startMs = now.getTime() - HOURS * 3600e3;

  const farms = [{ ...FARM, owner_id: null }];
  const layers = [], sensors = [], readings = [], alerts = [], irrigation = [], cropHealth = [];
  let sensorId = 0, readingId = 0, alertId = 0, irrigationId = 0, healthId = 0;

  const sensorsByLayer = {};
  for (const def of LAYER_DEFS) {
    layers.push({ id: def.id, farm_id: FARM.id, layer_name: def.layer_name, crop_type: def.crop_type, area: def.area, status: 'active' });
    sensorsByLayer[def.id] = {};
    for (const type of layerSensorTypes(def)) {
      sensorId += 1;
      const meta = SENSOR_META[type];
      sensors.push({ id: sensorId, layer_id: def.id, sensor_type: type, sensor_name: `L${def.id} ${meta.label} Sensor`, unit: meta.unit, status: 'online' });
      sensorsByLayer[def.id][type] = sensorId;
    }
  }

  const weather = new Weather();
  const states = Object.fromEntries(LAYER_DEFS.map((d) => [d.id, initialState(d)]));
  const lastIrrigationStep = {};
  const openAlerts = {}; // `${layer}|${type}` -> alert row

  for (let i = 0; i <= HOURS; i++) {
    const date = new Date(startMs + i * 3600e3);
    weather.step(1);
    const progress = Math.max(0, (i / 24 - 26) / 4); // late-month pH drift in the greenhouse

    for (const def of LAYER_DEFS) {
      const s = states[def.id];
      stepLayer(s, def, { date, dtH: 1, rain: weather.raining, phProgress: Math.min(1, progress) });

      // automatic irrigation when the soil dries out (Layer 2 is paused for the last ~40 h)
      const paused = def.pauseIrrigationLastH && HOURS - i < def.pauseIrrigationLastH;
      const cooledDown = i - (lastIrrigationStep[def.id] ?? -99) > 12;
      if (!paused && cooledDown && s.soil_moisture < def.irrigateBelow) {
        const duration = Math.round(25 + random() * 20);
        const litres = flowRate(def.area) * duration;
        for (let m = 0; m < duration; m++) applyIrrigation(s, def, flowRate(def.area));
        irrigationId += 1;
        irrigation.push({ id: irrigationId, layer_id: def.id, water_used: litres, duration, status: 'completed', timestamp: date.toISOString() });
        lastIrrigationStep[def.id] = i;
      }
      refillIfEmpty(s);

      // store hourly for the last 3 days, every 6 hours before that
      if (HOURS - i <= 72 || i % 6 === 0) {
        for (const type of layerSensorTypes(def)) {
          readingId += 1;
          readings.push({ id: readingId, sensor_id: sensorsByLayer[def.id][type], value: reading(s, type, weather.raining), timestamp: date.toISOString() });
        }
      }

      // daily crop-health snapshot (around midday) + one at "now"
      if (i % 24 === 12 || i === HOURS) {
        const score = scoreHealth(s, def.crop_type);
        healthId += 1;
        cropHealth.push({
          id: healthId, layer_id: def.id, health_score: Math.round(score * 10) / 10,
          disease_risk: diseaseRisk(s), growth_status: growthStatus(score), timestamp: date.toISOString(),
        });
      }

      // threshold alerts: open when violated, close when recovered
      const active = evaluateRules(s);
      const activeKeys = new Set();
      for (const a of active) {
        const key = `${def.id}|${a.alert_type}`;
        activeKeys.add(key);
        if (!openAlerts[key]) {
          alertId += 1;
          openAlerts[key] = { id: alertId, layer_id: def.id, alert_type: a.alert_type, message: a.message, severity: a.severity, status: 'active', timestamp: date.toISOString(), resolved_at: null };
          alerts.push(openAlerts[key]);
        } else if (a.severity === 'critical' && openAlerts[key].severity !== 'critical') {
          openAlerts[key].severity = 'critical';
          openAlerts[key].message = a.message;
        }
      }
      for (const key of Object.keys(openAlerts)) {
        if (key.startsWith(`${def.id}|`) && !activeKeys.has(key) && i < HOURS) {
          openAlerts[key].status = 'resolved';
          openAlerts[key].resolved_at = date.toISOString();
          delete openAlerts[key];
        }
      }
    }
  }
  setRng(null);

  // Informational alerts are not interesting once long past: keep them but mark the old ones resolved.
  for (const a of alerts) if (a.status === 'active' && !openAlerts[`${a.layer_id}|${a.alert_type}`]) a.status = 'resolved';

  return { farms, layers, sensors, sensor_readings: readings, alerts, irrigation, crop_health: cropHealth, users: [] };
}
