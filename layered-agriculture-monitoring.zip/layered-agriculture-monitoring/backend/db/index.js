import { useSupabase } from '../config/index.js';

// Cloud mode when Supabase env vars are present; in-memory demo mode otherwise.
const impl = useSupabase ? await import('./supabaseRepo.js') : await import('./memoryRepo.js');
export const repo = impl.default;
export const supabase = useSupabase ? impl.supabase : null;
