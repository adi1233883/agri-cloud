// Supabase (cloud PostgreSQL) implementation of the repository interface.
import { createClient } from '@supabase/supabase-js';
import { config, dbKey } from '../config/index.js';

export const supabase = createClient(config.supabaseUrl, dbKey, { auth: { persistSession: false, autoRefreshToken: false } });
const PAGE = 1000; // Supabase returns at most 1000 rows per request, so we page through results

const fail = (error, what) => {
  const e = new Error(`Database error while ${what}: ${error.message}`);
  e.status = 502;
  throw e;
};

export default {
  mode: 'supabase',
  async list(table, { eq, gte, lte, in: inn, order, limit } = {}) {
    const out = [];
    for (let from = 0; ; from += PAGE) {
      let q = supabase.from(table).select('*');
      if (eq) for (const [k, v] of Object.entries(eq)) q = q.eq(k, v);
      if (gte) for (const [k, v] of Object.entries(gte)) q = q.gte(k, v);
      if (lte) for (const [k, v] of Object.entries(lte)) q = q.lte(k, v);
      if (inn) for (const [k, v] of Object.entries(inn)) q = q.in(k, v);
      // always order for stable paging
      const [col, dir] = order || ['id', 'asc'];
      q = q.order(col, { ascending: dir !== 'desc' });
      const want = limit ? Math.min(PAGE, limit - out.length) : PAGE;
      const { data, error } = await q.range(from, from + want - 1);
      if (error) fail(error, `reading ${table}`);
      out.push(...data);
      if (data.length < want || (limit && out.length >= limit)) break;
    }
    return out;
  },
  async get(table, id) {
    const { data, error } = await supabase.from(table).select('*').eq('id', id).maybeSingle();
    if (error) fail(error, `reading ${table}`);
    return data;
  },
  async insert(table, rows) {
    const list = Array.isArray(rows) ? rows : [rows];
    const out = [];
    for (let i = 0; i < list.length; i += 500) {
      const { data, error } = await supabase.from(table).insert(list.slice(i, i + 500)).select();
      if (error) fail(error, `writing ${table}`);
      out.push(...data);
    }
    return Array.isArray(rows) ? out : out[0];
  },
  async update(table, id, patch) {
    const { data, error } = await supabase.from(table).update(patch).eq('id', id).select().maybeSingle();
    if (error) fail(error, `updating ${table}`);
    return data;
  },
  async deleteBefore(table, col, iso) {
    const { error } = await supabase.from(table).delete().lt(col, iso);
    if (error) fail(error, `cleaning ${table}`);
  },
};
