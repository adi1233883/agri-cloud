// In-memory database used in demo mode (no Supabase configured). Same interface as supabaseRepo.
import { generateSeed } from './seedData.js';

const tables = generateSeed();
const counters = {};
for (const [name, rows] of Object.entries(tables)) counters[name] = rows.reduce((m, r) => Math.max(m, Number(r.id) || 0), 0);

const matches = (row, { eq, gte, lte, in: inn }) => {
  if (eq) for (const [k, v] of Object.entries(eq)) if (row[k] !== v) return false;
  if (gte) for (const [k, v] of Object.entries(gte)) if (!(row[k] >= v)) return false;
  if (lte) for (const [k, v] of Object.entries(lte)) if (!(row[k] <= v)) return false;
  if (inn) for (const [k, v] of Object.entries(inn)) if (!v.includes(row[k])) return false;
  return true;
};

export default {
  mode: 'memory',
  async list(table, opts = {}) {
    let rows = (tables[table] || []).filter((r) => matches(r, opts));
    if (opts.order) {
      const [col, dir = 'asc'] = opts.order;
      rows = [...rows].sort((a, b) => (a[col] > b[col] ? 1 : a[col] < b[col] ? -1 : 0) * (dir === 'desc' ? -1 : 1));
    }
    if (opts.limit) rows = rows.slice(0, opts.limit);
    return rows.map((r) => ({ ...r }));
  },
  async get(table, id) {
    const r = (tables[table] || []).find((x) => String(x.id) === String(id));
    return r ? { ...r } : null;
  },
  async insert(table, data) {
    const list = Array.isArray(data) ? data : [data];
    const out = list.map((row) => {
      const withId = { ...row };
      if (withId.id == null && table !== 'users') withId.id = ++counters[table];
      tables[table].push(withId);
      return { ...withId };
    });
    return Array.isArray(data) ? out : out[0];
  },
  async update(table, id, patch) {
    const r = (tables[table] || []).find((x) => String(x.id) === String(id));
    if (!r) return null;
    Object.assign(r, patch);
    return { ...r };
  },
  async deleteBefore(table, col, iso) {
    tables[table] = tables[table].filter((r) => r[col] >= iso);
  },
};
