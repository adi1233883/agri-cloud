// Sensor simulator: generates gradual, realistic readings, stores them in the (cloud) database,
// runs irrigation effects and triggers threshold alerts. Replace with real IoT ingestion later.
import { repo } from '../db/index.js';
import { config } from '../config/index.js';
import { LAYER_DEFS, genericDef, SENSOR_META, flowRate, scoreHealth, diseaseRisk, growthStatus } from '../config/agri.js';
import { Weather, initialState, stepLayer, applyIrrigation, refillIfEmpty, reading } from './model.js';
import { runtime } from '../models/runtime.js';
import { evaluateLayer } from '../services/alertService.js';

export class Simulator {
  constructor() {
    this.layers = []; this.sensors = []; this.states = new Map(); this.defs = new Map();
    this.live = {}; this.updatedAt = null; this.weather = new Weather();
    this.ticks = 0; this.persists = 0; this.timer = null; this.busy = false;
  }

  async refreshTopology() {
    this.layers = (await repo.list('layers')).filter((l) => l.status === 'active');
    this.sensors = await repo.list('sensors');
    for (const l of this.layers) {
      if (!this.defs.has(l.id)) this.defs.set(l.id, LAYER_DEFS.find((d) => d.id === l.id && d.crop_type === l.crop_type) || genericDef(l));
      if (!this.states.has(l.id)) this.states.set(l.id, await this.loadState(l));
    }
  }

  // continue from the most recent stored readings so charts stay smooth after a restart
  async loadState(layer) {
    const def = this.defs.get(layer.id);
    const s = initialState(def);
    for (const sensor of this.sensors.filter((x) => x.layer_id === layer.id)) {
      const last = (await repo.list('sensor_readings', { eq: { sensor_id: sensor.id }, order: ['timestamp', 'desc'], limit: 1 }))[0];
      if (last) s[sensor.sensor_type] = Number(last.value);
    }
    return s;
  }

  async start() {
    for (const row of await repo.list('irrigation', { eq: { status: 'running' } })) runtime.running.set(row.layer_id, row.id);
    await this.refreshTopology();
    this.compute(new Date(), 0);
    this.timer = setInterval(() => this.tick().catch((e) => console.error('[simulator]', e.message)), config.sim.tickMs);
    this.timer.unref?.();
    console.log(`[simulator] running — live update every ${config.sim.tickMs / 1000}s, saved every ${(config.sim.tickMs * config.sim.persistEvery) / 1000}s`);
  }

  stop() { clearInterval(this.timer); }

  snapshot() { return this.updatedAt ? { updatedAt: this.updatedAt, values: this.live } : null; }

  compute(date, dtH) {
    this.weather.step(dtH);
    for (const l of this.layers) {
      const def = this.defs.get(l.id);
      const s = this.states.get(l.id);
      if (dtH > 0) stepLayer(s, def, { date, dtH, rain: this.weather.raining, phProgress: 1 });
      const values = {};
      for (const sensor of this.sensors.filter((x) => x.layer_id === l.id)) values[sensor.sensor_type] = reading(s, sensor.sensor_type, this.weather.raining);
      this.live[l.id] = values;
    }
    this.updatedAt = date.toISOString();
  }

  async irrigate() {
    for (const [layerId, rowId] of [...runtime.running.entries()]) {
      const layer = this.layers.find((l) => l.id === layerId);
      const s = this.states.get(layerId);
      if (!layer || !s) { runtime.running.delete(layerId); continue; }
      const def = this.defs.get(layerId);
      const litres = flowRate(def.area);
      applyIrrigation(s, def, litres);
      const row = await repo.get('irrigation', rowId);
      if (!row || row.status !== 'running') { runtime.running.delete(layerId); continue; }
      const done = s.soil_moisture >= 68 || s.water_level < 3; // one tick represents one simulated minute
      await repo.update('irrigation', rowId, { duration: row.duration + 1, water_used: Number(row.water_used) + litres, status: done ? 'completed' : 'running' });
      if (done) runtime.running.delete(layerId);
    }
  }

  async tick() {
    if (this.busy) return;
    this.busy = true;
    try {
      this.ticks += 1;
      const date = new Date();
      await this.irrigate();
      for (const s of this.states.values()) refillIfEmpty(s);
      this.compute(date, config.sim.tickMs / 3600e3);
      if (this.ticks % config.sim.persistEvery === 0) await this.persist(date);
    } finally { this.busy = false; }
  }

  async persist(date) {
    await this.refreshTopology();
    const rows = [];
    for (const sensor of this.sensors) {
      const v = this.live[sensor.layer_id]?.[sensor.sensor_type];
      if (v != null) rows.push({ sensor_id: sensor.id, value: v, timestamp: date.toISOString() });
    }
    if (rows.length) await repo.insert('sensor_readings', rows);
    this.persists += 1;
    const takeHealth = this.persists % config.sim.healthEveryPersists === 0;
    for (const l of this.layers) {
      const vals = this.live[l.id] || {};
      await evaluateLayer(l.id, vals, date);
      if (takeHealth && vals.soil_moisture != null) {
        const score = scoreHealth(vals, l.crop_type);
        await repo.insert('crop_health', { layer_id: l.id, health_score: Math.round(score * 10) / 10, disease_risk: diseaseRisk(vals), growth_status: growthStatus(score), timestamp: date.toISOString() });
      }
    }
    if (this.persists % 60 === 0) {
      const cutoff = new Date(Date.now() - config.sim.retentionDays * 86400e3).toISOString();
      await repo.deleteBefore('sensor_readings', 'timestamp', cutoff);
    }
  }
}
export { SENSOR_META };
