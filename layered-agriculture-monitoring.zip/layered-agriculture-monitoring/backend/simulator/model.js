// Realistic sensor model: values follow smooth, mean-reverting random walks driven by time of day,
// weather and irrigation — never independent random numbers.
import { SENSOR_META } from '../config/agri.js';

let rand = Math.random;
export const setRng = (fn) => { rand = fn || Math.random; };
export const random = () => rand();

// seeded generator so the demo data is reproducible
export function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const gauss = () => {
  let u = 0, v = 0;
  while (!u) u = rand();
  while (!v) v = rand();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
};
export const clamp = (x, [a, b]) => Math.min(b, Math.max(a, x));
const hourOf = (d) => d.getHours() + d.getMinutes() / 60;
const diurnal = (d) => Math.sin(((hourOf(d) - 9) / 24) * 2 * Math.PI); // warmest ~15:00
const sun = (d) => Math.max(0, Math.sin((Math.PI * (hourOf(d) - 6)) / 12)); // 0 at night, 1 at noon

/** Shared weather: occasional rain episodes affecting outdoor layers. */
export class Weather {
  constructor() { this.raining = 0; this.remaining = 0; }
  step(dtH) {
    if (this.remaining > 0) {
      this.remaining -= dtH;
      if (this.remaining <= 0) this.raining = 0;
    } else if (rand() < 0.018 * dtH) {
      this.remaining = 1 + rand() * 3;
      this.raining = 2 + rand() * 8;
    }
  }
}

export function initialState(def) {
  return { ...def.base, rainfall: 0, co2: 620 };
}

/** Advance one layer's physical state by dtH hours. */
export function stepLayer(s, def, { date, dtH, rain = 0, phProgress = 1 }) {
  const k = (tau) => 1 - Math.exp(-dtH / tau);
  const root = Math.sqrt(dtH);
  const d = diurnal(date);
  const sunny = sun(date);
  const wet = def.outdoor && rain > 0;

  s.temperature += (def.base.temperature + def.tempSwing * d - (wet ? 2 : 0) - s.temperature) * k(3) + gauss() * 0.25 * root;
  s.humidity += (def.base.humidity - 9 * d + (wet ? 12 : 0) - s.humidity) * k(2.5) + gauss() * 0.8 * root;
  const evaporation = 0.3 * (s.temperature / 26) * dtH * (def.outdoor ? 1 : 0.8);
  s.soil_moisture += -evaporation + (wet ? rain * 0.16 * dtH : 0) + gauss() * 0.1 * root;
  const phTarget = def.base.soil_ph + (def.phEnd - def.base.soil_ph) * phProgress;
  s.soil_ph += (phTarget - s.soil_ph) * k(60) + gauss() * 0.012 * root;
  const lightTarget = 200 + (def.lightMax - 200) * sunny * (wet ? 0.6 : 1);
  s.light += (lightTarget - s.light) * k(0.6) + gauss() * 6 * root;
  s.water_level -= 0.04 * dtH;
  if (def.hasCo2) s.co2 += (620 - 170 * sunny - s.co2) * k(1.5) + gauss() * 9 * root;
  s.rainfall = def.outdoor ? rain : 0;

  for (const key of Object.keys(s)) if (SENSOR_META[key]) s[key] = clamp(s[key], SENSOR_META[key].range);
  return s;
}

/** One simulated minute of irrigation: soil moisture rises, the tank drains. */
export function applyIrrigation(s, def, litres) {
  s.soil_moisture = clamp(s.soil_moisture + 0.6, SENSOR_META.soil_moisture.range);
  s.water_level = clamp(s.water_level - (litres / def.tankLitres) * 100, SENSOR_META.water_level.range);
}

export function refillIfEmpty(s) {
  if (s.water_level < 6) s.water_level = 95; // the tank is refilled
}

/** What a sensor would report right now: true value plus small measurement noise. */
export function reading(s, type, rain = 0) {
  const meta = SENSOR_META[type];
  let v = s[type];
  if (type === 'rainfall') v = rain > 0 ? rain * (0.8 + 0.4 * rand()) : 0;
  else v += gauss() * meta.jitter;
  v = clamp(v, meta.range);
  const f = 10 ** meta.decimals;
  return Math.round(v * f) / f;
}
