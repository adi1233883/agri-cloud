// Applies database/schema.sql and (optionally) seed.sql to the Supabase Postgres using DATABASE_URL.
//   npm run migrate            -> schema + seed
//   npm run migrate -- --no-seed
import 'dotenv/config';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import pg from 'pg';

const dir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../database');
if (!process.env.DATABASE_URL) { console.error('DATABASE_URL is not set. Copy it from Supabase → Project Settings → Database.'); process.exit(1); }
const client = new pg.Client({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
await client.connect();
try {
  console.log('Applying schema.sql …');
  await client.query(readFileSync(path.join(dir, 'schema.sql'), 'utf8'));
  if (!process.argv.includes('--no-seed')) {
    console.log('Applying seed.sql … (a few seconds)');
    await client.query(readFileSync(path.join(dir, 'seed.sql'), 'utf8'));
  }
  console.log('Done ✔');
} catch (e) { console.error('Migration failed:', e.message); process.exitCode = 1; } finally { await client.end(); }
