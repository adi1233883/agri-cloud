// Creates demo admin and viewer accounts in Supabase Auth (needs SUPABASE_SERVICE_ROLE_KEY).
import 'dotenv/config';
import { createClient } from '@supabase/supabase-js';

const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) { console.error('Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in backend/.env first.'); process.exit(1); }
const sb = createClient(url, key, { auth: { persistSession: false } });
const users = [
  { email: 'admin@agri.demo', password: 'Admin@123', name: 'Farm Admin', role: 'admin' },
  { email: 'viewer@agri.demo', password: 'Viewer@123', name: 'Farm Viewer', role: 'viewer' },
];
for (const u of users) {
  let id;
  const { data, error } = await sb.auth.admin.createUser({ email: u.email, password: u.password, email_confirm: true, user_metadata: { name: u.name } });
  if (error) {
    if (!/already/i.test(error.message)) { console.error(u.email, '→', error.message); continue; }
    const list = await sb.auth.admin.listUsers({ perPage: 200 });
    id = list.data.users.find((x) => x.email === u.email)?.id;
  } else id = data.user.id;
  const { error: e2 } = await sb.from('users').upsert({ id, email: u.email, name: u.name, role: u.role });
  console.log(e2 ? `${u.email} → profile error: ${e2.message}` : `${u.email} (${u.role}) ready`);
}
