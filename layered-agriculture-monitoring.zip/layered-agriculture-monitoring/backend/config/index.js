import 'dotenv/config';

const env = process.env;

export const config = {
  port: Number(env.PORT) || 4000,
  corsOrigins: (env.CORS_ORIGIN || 'http://localhost:5173').split(',').map((s) => s.trim()),
  supabaseUrl: env.SUPABASE_URL || '',
  // The backend writes data, so it needs the service-role key (bypasses RLS).
  // It falls back to the anon key, which is enough only for verifying logins.
  supabaseServiceKey: env.SUPABASE_SERVICE_ROLE_KEY || '',
  supabaseAnonKey: env.SUPABASE_ANON_KEY || '',
  databaseUrl: env.DATABASE_URL || '',
  demoJwtSecret: env.DEMO_JWT_SECRET || 'dev-only-secret-change-me',
  deviceApiKey: env.DEVICE_API_KEY || '',
  sim: {
    enabled: env.SIMULATOR_ENABLED !== 'false',
    tickMs: Number(env.SIM_TICK_MS) || 5000, // live value refresh
    persistEvery: Number(env.SIM_PERSIST_EVERY) || 12, // save to DB every N ticks (12 x 5s = 1 min)
    healthEveryPersists: 10, // crop-health snapshot every N saves
    retentionDays: Number(env.READINGS_RETENTION_DAYS) || 45,
  },
};

// Cloud mode = Supabase configured. Otherwise the app runs in "demo mode" with an in-memory database.
export const dbKey = config.supabaseServiceKey || config.supabaseAnonKey;
export const useSupabase = Boolean(config.supabaseUrl && dbKey);
