// Agronomy knowledge shared by the simulator, alert engine, analytics and seed generator.

export const SENSOR_META = {
  temperature:   { label: 'Temperature',      unit: '°C',   range: [20, 38],    jitter: 0.15, decimals: 1 },
  humidity:      { label: 'Humidity',         unit: '%',    range: [40, 90],    jitter: 0.4,  decimals: 1 },
  soil_moisture: { label: 'Soil Moisture',    unit: '%',    range: [20, 80],    jitter: 0.15, decimals: 1 },
  soil_ph:       { label: 'Soil pH',          unit: 'pH',   range: [5.3, 8],    jitter: 0.01, decimals: 2 },
  light:         { label: 'Light Intensity',  unit: 'lux',  range: [200, 1000], jitter: 6,    decimals: 0 },
  water_level:   { label: 'Water Tank Level', unit: '%',    range: [0, 100],    jitter: 0.08, decimals: 1 },
  co2:           { label: 'CO₂ Level',        unit: 'ppm',  range: [350, 1200], jitter: 4,    decimals: 0 },
  rainfall:      { label: 'Rainfall',         unit: 'mm/h', range: [0, 15],     jitter: 0.05, decimals: 1 },
};

// Preferred growing conditions per crop (used for insights and the crop-health score).
export const CROP_PROFILES = {
  Tomato:        { temperature: [18, 30], soil_moisture: [40, 65], soil_ph: [6.0, 6.8], humidity: [55, 80] },
  Papaya:        { temperature: [22, 32], soil_moisture: [40, 60], soil_ph: [6.0, 7.0], humidity: [50, 80] },
  Wheat:         { temperature: [15, 28], soil_moisture: [35, 60], soil_ph: [6.0, 7.5], humidity: [45, 70] },
  'Bell Pepper': { temperature: [20, 30], soil_moisture: [45, 65], soil_ph: [5.8, 6.8], humidity: [60, 80] },
  default:       { temperature: [18, 32], soil_moisture: [40, 65], soil_ph: [6.0, 7.2], humidity: [50, 80] },
};
export const profileFor = (crop) => CROP_PROFILES[crop] || CROP_PROFILES.default;

export const FARM = { id: 1, farm_name: 'Green Valley Farm', location: 'Pune, Maharashtra, India', total_area: 10 };

// The four demo layers. `base` values drive the simulator; area is in hectares.
export const LAYER_DEFS = [
  { id: 1, layer_name: 'Layer 1 — Vegetable Zone', crop_type: 'Tomato', area: 3.0, outdoor: true, tempSwing: 3, lightMax: 900, irrigateBelow: 36, tankLitres: 12000,
    base: { temperature: 26, humidity: 68, soil_moisture: 52, soil_ph: 6.5, light: 650, water_level: 78 }, phEnd: 6.5 },
  { id: 2, layer_name: 'Layer 2 — Fruit Zone', crop_type: 'Papaya', area: 2.5, outdoor: true, tempSwing: 3.5, lightMax: 950, irrigateBelow: 35, tankLitres: 12000, pauseIrrigationLastH: 40,
    base: { temperature: 30, humidity: 62, soil_moisture: 46, soil_ph: 6.8, light: 700, water_level: 66 }, phEnd: 6.8 },
  { id: 3, layer_name: 'Layer 3 — Grain Zone', crop_type: 'Wheat', area: 3.5, outdoor: true, tempSwing: 3.5, lightMax: 1000, irrigateBelow: 34, tankLitres: 12000,
    base: { temperature: 25, humidity: 55, soil_ph: 7.0, soil_moisture: 52, light: 750, water_level: 38 }, phEnd: 7.0 },
  { id: 4, layer_name: 'Layer 4 — Greenhouse Zone', crop_type: 'Bell Pepper', area: 1.0, outdoor: false, tempSwing: 5, lightMax: 820, irrigateBelow: 38, tankLitres: 12000, hasCo2: true,
    base: { temperature: 31, humidity: 75, soil_moisture: 55, soil_ph: 6.0, light: 600, water_level: 82 }, phEnd: 5.42 },
];

export function layerSensorTypes(def) {
  const types = ['temperature', 'humidity', 'soil_moisture', 'soil_ph', 'light', 'water_level'];
  if (def.outdoor) types.push('rainfall');
  if (def.hasCo2) types.push('co2');
  return types;
}

// A generic definition for layers an admin adds later.
export function genericDef(layer) {
  const p = profileFor(layer.crop_type);
  const mid = (r) => (r[0] + r[1]) / 2;
  return {
    id: layer.id, layer_name: layer.layer_name, crop_type: layer.crop_type, area: Number(layer.area) || 1,
    outdoor: true, tempSwing: 3, lightMax: 900, irrigateBelow: 35, tankLitres: 12000,
    base: { temperature: mid(p.temperature), humidity: mid(p.humidity), soil_moisture: mid(p.soil_moisture),
            soil_ph: mid(p.soil_ph), light: 650, water_level: 80 },
    phEnd: mid(p.soil_ph),
  };
}
export const flowRate = (area) => Math.max(1, Math.round(Number(area) * 20)); // litres per minute

// ---- alert rules ----------------------------------------------------------
export const SEVERITY_ORDER = { critical: 0, warning: 1, info: 2 };

/** Returns every rule currently violated for a set of readings. */
export function evaluateRules(v) {
  const out = [];
  const f = (x, d = 1) => Number(x).toFixed(d);
  if (v.soil_moisture != null) {
    if (v.soil_moisture < 30) out.push({ alert_type: 'low_soil_moisture', severity: v.soil_moisture < 22 ? 'critical' : 'warning', message: `Low soil moisture detected (${f(v.soil_moisture)}%).` });
    else if (v.soil_moisture < 35) out.push({ alert_type: 'soil_moisture_falling', severity: 'info', message: `Soil moisture is approaching the dry threshold (${f(v.soil_moisture)}%).` });
  }
  if (v.temperature != null && v.temperature > 35)
    out.push({ alert_type: 'high_temperature', severity: v.temperature > 37.5 ? 'critical' : 'warning', message: `High temperature warning (${f(v.temperature)}°C).` });
  if (v.soil_ph != null && v.soil_ph < 5.5)
    out.push({ alert_type: 'low_ph', severity: v.soil_ph < 5.0 ? 'critical' : 'warning', message: `Soil pH below recommended range (${f(v.soil_ph, 2)}).` });
  if (v.water_level != null && v.water_level < 20)
    out.push({ alert_type: 'low_water_level', severity: v.water_level < 10 ? 'critical' : 'warning', message: `Low water tank level (${f(v.water_level)}%).` });
  if (v.humidity != null && v.humidity > 85)
    out.push({ alert_type: 'high_humidity', severity: 'info', message: `Humidity above 85% (${f(v.humidity)}%) — watch for fungal disease.` });
  return out;
}

// ---- crop health ----------------------------------------------------------
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));

/** 0–100 score from current conditions versus the crop's preferred ranges. */
export function scoreHealth(v, crop) {
  const p = profileFor(crop);
  const [mLo, mHi] = p.soil_moisture;
  const m = v.soil_moisture;
  const moist = m < mLo ? 90 - (mLo - m) * 3 : m > mHi ? 100 - (m - mHi) * 3 : 90 + (10 * (m - mLo)) / (mHi - mLo);
  const [tLo, tHi] = p.temperature;
  const t = v.temperature;
  const temp = t > tHi ? 100 - (t - tHi) * 7 : t < tLo ? 100 - (tLo - t) * 7 : 100;
  const [pLo, pHi] = p.soil_ph;
  const ph = v.soil_ph < pLo ? 100 - (pLo - v.soil_ph) * 30 : v.soil_ph > pHi ? 100 - (v.soil_ph - pHi) * 30 : 100;
  const [hLo, hHi] = p.humidity;
  const hum = v.humidity > hHi ? 100 - (v.humidity - hHi) * 2 : v.humidity < hLo ? 100 - (hLo - v.humidity) * 2 : 100;
  return clamp(0.45 * clamp(moist, 0, 100) + 0.3 * clamp(temp, 0, 100) + 0.15 * clamp(ph, 0, 100) + 0.1 * clamp(hum, 0, 100), 0, 100);
}
export function diseaseRisk(v) {
  if (v.humidity > 82 && v.temperature >= 18 && v.temperature <= 32) return 'High';
  if (v.humidity > 74) return 'Medium';
  return 'Low';
}
export const growthStatus = (score) => (score >= 85 ? 'Healthy' : score >= 70 ? 'Moderate' : 'Stressed');
