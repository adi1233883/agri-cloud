import { repo } from '../db/index.js';
import { evaluateRules } from '../config/agri.js';

/**
 * Compare live readings against thresholds. Opens an alert when a rule is first violated
 * (no duplicates while one is still active) and auto-closes it when the value recovers.
 */
export async function evaluateLayer(layerId, values, when = new Date()) {
  const active = await repo.list('alerts', { eq: { layer_id: layerId, status: 'active' } });
  const violated = evaluateRules(values);
  const violatedTypes = new Set(violated.map((v) => v.alert_type));
  const created = [];

  for (const v of violated) {
    const existing = active.find((a) => a.alert_type === v.alert_type);
    if (!existing) {
      created.push(await repo.insert('alerts', { layer_id: layerId, ...v, status: 'active', timestamp: when.toISOString(), resolved_at: null }));
    } else if (existing.severity !== v.severity || existing.message !== v.message) {
      await repo.update('alerts', existing.id, { severity: v.severity, message: v.message });
    }
  }
  for (const a of active) {
    if (!violatedTypes.has(a.alert_type)) await repo.update('alerts', a.id, { status: 'resolved', resolved_at: when.toISOString() });
  }
  return created;
}

export async function resolveAlert(id) {
  const alert = await repo.get('alerts', id);
  if (!alert) return null;
  if (alert.status === 'resolved') return alert;
  return repo.update('alerts', id, { status: 'resolved', resolved_at: new Date().toISOString() });
}
