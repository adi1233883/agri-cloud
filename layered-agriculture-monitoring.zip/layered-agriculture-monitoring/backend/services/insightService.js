import { profileFor, SEVERITY_ORDER } from '../config/agri.js';
import { repo } from '../db/index.js';
import { runtime } from '../models/runtime.js';
import { windowFor, loadWindow, avg, sum, round, pct } from '../models/timeseries.js';
import { getLatestValues } from './liveService.js';
import { describe } from './analyticsService.js';

const sub = (win, id) => ({ ...win, readings: win.readings.filter((r) => r.layer_id === id), irrigation: win.irrigation.filter((r) => r.layer_id === id), health: win.health.filter((r) => r.layer_id === id), alerts: win.alerts.filter((r) => r.layer_id === id) });
const short = (l) => l.layer_name.split('—')[0].trim(); // "Layer 2"

/** Insights are computed from real readings, never hardcoded. */
export async function generateInsights(layers) {
  if (!layers.length) return [];
  const [today, week, prevWeek, latest] = await Promise.all([
    loadWindow(layers, windowFor('today')), loadWindow(layers, windowFor('7d')), loadWindow(layers, windowFor('7d', 1)), getLatestValues(layers),
  ]);
  const out = [];
  const add = (item) => out.push({ id: `${item.kind}-${item.layerId ?? 'farm'}-${out.length}`, ...item });

  const todayStats = Object.fromEntries(layers.map((l) => [l.id, describe(sub(today, l.id))]));
  const farmMoisture = avg(layers.map((l) => todayStats[l.id].averageSoilMoisture));
  const totalWater = sum(layers.map((l) => describe(sub(week, l.id)).totalWaterUsage));

  for (const l of layers) {
    const v = latest.values[l.id] || {};
    const p = profileFor(l.crop_type);
    const name = short(l);

    // 1. soil moisture relative to the rest of the farm
    const m = todayStats[l.id].averageSoilMoisture;
    if (m != null && farmMoisture) {
      const diff = round(((m - farmMoisture) / farmMoisture) * 100, 0);
      if (diff <= -10) add({ kind: 'insight', layerId: l.id, severity: diff <= -15 ? 'warning' : 'info', title: 'Dry compared with the farm', text: `${name} has ${Math.abs(diff)}% lower soil moisture than the farm average (${m}% vs ${round(farmMoisture, 0)}%).` });
      else if (diff >= 15) add({ kind: 'insight', layerId: l.id, severity: 'info', title: 'Wetter than the farm', text: `${name} has ${diff}% higher soil moisture than the farm average (${m}% vs ${round(farmMoisture, 0)}%).` });
    }
    // 2. irrigation recommendation
    if (v.soil_moisture != null && v.soil_moisture < 36 && !runtime.running.has(l.id))
      add({ kind: 'recommendation', layerId: l.id, severity: v.soil_moisture < 30 ? 'warning' : 'info', title: 'Irrigation recommended', text: `Irrigation is recommended for ${name}. Soil moisture is ${v.soil_moisture.toFixed(1)}%, below the comfortable level for ${l.crop_type} (${p.soil_moisture[0]}–${p.soil_moisture[1]}%).` });
    // 3. temperature trend over 7 days
    const t1 = describe(sub(week, l.id)).averageTemperature, t0 = describe(sub(prevWeek, l.id)).averageTemperature;
    const tc = pct(t1, t0);
    if (tc != null && Math.abs(tc) >= 4)
      add({ kind: 'insight', layerId: l.id, severity: tc > 0 && t1 > p.temperature[1] ? 'warning' : 'info', title: `Temperature ${tc > 0 ? 'rising' : 'falling'}`, text: `Temperature in ${name} has ${tc > 0 ? 'increased' : 'decreased'} by ${Math.abs(tc)}% over the last 7 days (${t0}°C → ${t1}°C).` });
    // 4. outside the crop's preferred temperature range
    if (v.temperature != null && v.temperature > p.temperature[1])
      add({ kind: 'warning', layerId: l.id, severity: 'warning', title: 'Above preferred temperature', text: `${name} has exceeded the preferred temperature range for ${l.crop_type} (${p.temperature[0]}–${p.temperature[1]}°C). It is now ${v.temperature.toFixed(1)}°C. Consider shading or ventilation.` });
    // 5. pH
    if (v.soil_ph != null && (v.soil_ph < p.soil_ph[0] || v.soil_ph > p.soil_ph[1]))
      add({ kind: 'recommendation', layerId: l.id, severity: 'warning', title: 'Soil pH out of range', text: `Soil pH in ${name} is ${v.soil_ph.toFixed(2)}, outside the ${p.soil_ph[0]}–${p.soil_ph[1]} range preferred by ${l.crop_type}. ${v.soil_ph < p.soil_ph[0] ? 'Consider liming to raise pH.' : 'Consider sulphur or organic matter to lower pH.'}` });
    // 6. crop-health decline
    const h1 = describe(sub(week, l.id)).averageCropHealth, h0 = describe(sub(prevWeek, l.id)).averageCropHealth;
    if (h1 != null && h0 != null && h0 - h1 >= 4)
      add({ kind: 'warning', layerId: l.id, severity: 'warning', title: 'Crop health declining', text: `Average crop health in ${name} fell ${round(h0 - h1, 1)} points compared with the previous week (${h0}% → ${h1}%).` });
    // 7. disease risk
    const lastHealth = (await repo.list('crop_health', { eq: { layer_id: l.id }, order: ['timestamp', 'desc'], limit: 1 }))[0];
    if (lastHealth?.disease_risk === 'High')
      add({ kind: 'recommendation', layerId: l.id, severity: 'warning', title: 'High disease risk', text: `Warm, humid conditions in ${name} raise fungal disease risk. Improve airflow and avoid watering late in the day.` });
    // 8. water share
    const w = describe(sub(week, l.id)).totalWaterUsage;
    if (totalWater > 0 && layers.length > 1 && w / totalWater >= 0.4)
      add({ kind: 'insight', layerId: l.id, severity: 'info', title: 'Largest water user', text: `${name} used ${Math.round((w / totalWater) * 100)}% of this week's irrigation water (${w.toLocaleString('en-IN')} L).` });
  }
  if (!out.length) add({ kind: 'insight', layerId: null, severity: 'good', title: 'All clear', text: 'Every layer is within the preferred range for its crop.' });
  const order = { ...SEVERITY_ORDER, good: 3 };
  return out.sort((a, b) => order[a.severity] - order[b.severity]);
}
