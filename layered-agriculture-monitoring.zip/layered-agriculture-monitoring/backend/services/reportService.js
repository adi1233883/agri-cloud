import { profileFor } from '../config/agri.js';
import { windowFor, loadWindow, buildTable, GRANULARITY, avg, round } from '../models/timeseries.js';
import { describe } from './analyticsService.js';

const LABEL = { today: 'Daily', '7d': 'Weekly', '30d': 'Monthly' };
export const REPORT_METRICS = ['temperature', 'humidity', 'soil_moisture', 'soil_ph', 'water_usage', 'crop_health', 'alerts'];

export async function buildReport(layers, selected, range, metrics) {
  const scope = selected ? [selected] : layers;
  const win = await loadWindow(scope, windowFor(range));
  const d = describe(win);
  const all = {
    temperature: { label: 'Average Temperature', value: d.averageTemperature, unit: '°C' },
    humidity: { label: 'Average Humidity', value: d.averageHumidity, unit: '%' },
    soil_moisture: { label: 'Average Soil Moisture', value: d.averageSoilMoisture, unit: '%' },
    soil_ph: { label: 'Average Soil pH', value: d.averageSoilPh, unit: '' },
    water_usage: { label: 'Water Used', value: d.totalWaterUsage, unit: 'L' },
    crop_health: { label: 'Crop Health', value: d.averageCropHealth, unit: '%' },
    alerts: { label: 'Alerts', value: d.alertCount, unit: '' },
  };
  const stats = metrics.map((m) => ({ key: m, ...all[m] }));

  // recommendations from the window's actual numbers
  const rows = buildTable(win, GRANULARITY[range] === 'hour' ? '6h' : GRANULARITY[range]);
  const moist = rows.map((r) => r.soil_moisture).filter((x) => x != null);
  const half = Math.floor(moist.length / 2);
  const delta = moist.length > 3 ? avg(moist.slice(half)) - avg(moist.slice(0, half)) : 0;
  const crops = [...new Set(scope.map((l) => l.crop_type))];
  const tMax = Math.min(...crops.map((c) => profileFor(c).temperature[1]));
  const recs = [];
  if (d.averageSoilMoisture != null && d.averageSoilMoisture < 40 && delta < -1) recs.push('Increase irrigation frequency due to declining soil moisture.');
  else if (delta < -3) recs.push('Soil moisture is trending down — plan the next irrigation cycle.');
  if (d.averageTemperature != null && d.averageTemperature > tMax) recs.push('Average temperature is above the preferred range — improve shading or ventilation.');
  if (d.averageCropHealth != null && d.averageCropHealth < 75) recs.push('Crop health is below 75% — schedule a field inspection.');
  if (d.alertCount >= 6) recs.push('Many alerts were raised in this period — review the recurring causes.');
  if (!recs.length) recs.push('Conditions are stable. Continue the current irrigation and monitoring routine.');

  return {
    title: `${selected ? selected.layer_name : 'All Layers'} — ${LABEL[range]} Agricultural Report`,
    range, generatedAt: new Date().toISOString(), period: { from: win.readings.length ? windowFor(range).start : null, to: windowFor(range).end },
    stats, recommendations: recs, recommendation: recs[0],
    table: rows.slice(-60).map((r) => ({ ...r, layer: layers.find((l) => l.id === r.layer_id)?.layer_name, temperature: round(r.temperature), humidity: round(r.humidity), soil_moisture: round(r.soil_moisture), soil_ph: round(r.soil_ph, 2), crop_health: round(r.crop_health) })),
  };
}

const esc = (v) => { const s = v == null ? '' : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };

export async function buildCsv(layers, selected, range) {
  const scope = selected ? [selected] : layers;
  const rows = buildTable(await loadWindow(scope, windowFor(range)), GRANULARITY[range]);
  const head = ['Timestamp', 'Layer', 'Temperature (°C)', 'Humidity (%)', 'Soil Moisture (%)', 'pH', 'Water Usage (L)', 'Crop Health (%)'];
  const lines = rows.map((r) => [r.bucket, layers.find((l) => l.id === r.layer_id)?.layer_name, round(r.temperature), round(r.humidity), round(r.soil_moisture), round(r.soil_ph, 2), r.water_usage, round(r.crop_health)].map(esc).join(','));
  return '\uFEFF' + [head.join(','), ...lines].join('\n');
}
