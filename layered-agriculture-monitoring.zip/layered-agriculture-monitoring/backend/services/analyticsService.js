import { SENSOR_META, SEVERITY_ORDER } from '../config/agri.js';
import { repo } from '../db/index.js';
import { HOURS, GRANULARITY, windowFor, loadWindow, buildTable, avg, sum, round, pct, bucketKey } from '../models/timeseries.js';

const layerKey = (id) => `L${id}`;

/** Descriptive statistics for one window (all layers or a subset). */
export function describe(win) {
  const of = (type) => win.readings.filter((r) => r.type === type).map((r) => r.value);
  const temps = of('temperature');
  return {
    averageTemperature: round(avg(temps)),
    maxTemperature: temps.length ? round(Math.max(...temps)) : null,
    minTemperature: temps.length ? round(Math.min(...temps)) : null,
    averageHumidity: round(avg(of('humidity'))),
    averageSoilMoisture: round(avg(of('soil_moisture'))),
    averageSoilPh: round(avg(of('soil_ph')), 2),
    averageLight: round(avg(of('light')), 0),
    totalWaterUsage: Math.round(sum(win.irrigation.map((w) => w.water_used))),
    averageCropHealth: round(avg(win.health.map((h) => Number(h.health_score)))),
    alertCount: win.alerts.length,
    readingCount: win.readings.length,
  };
}

export async function summary(layers, range) {
  const win = await loadWindow(layers, windowFor(range));
  const prevWin = await loadWindow(layers, windowFor(range, 1));
  const current = describe(win);
  const previous = describe(prevWin);
  const change = {};
  for (const k of Object.keys(current)) change[k] = pct(current[k], previous[k]);
  const activeAlerts = await loadActiveAlertCount(layers);
  return { range, ...current, activeAlerts, change, previous };
}

async function loadActiveAlertCount(layers) {
  if (!layers.length) return 0;
  const rows = await repo.list('alerts', { eq: { status: 'active' }, in: { layer_id: layers.map((l) => l.id) } });
  return rows.length;
}

/** Time series per metric, with one key per layer plus a farm-wide value. */
export async function trends(layers, range) {
  const win = await loadWindow(layers, windowFor(range));
  const gran = GRANULARITY[range];
  const rows = buildTable(win, gran);
  const buckets = [...new Set(rows.map((r) => r.bucket))].sort();
  const metrics = { temperature: 'temperature', humidity: 'humidity', soil_moisture: 'soil_moisture', light: 'light', water_usage: 'water_usage', crop_health: 'crop_health' };
  const out = {};
  for (const [name, field] of Object.entries(metrics)) {
    out[name] = buckets.map((b) => {
      const point = { t: b };
      const vals = [];
      for (const l of layers) {
        const r = rows.find((x) => x.bucket === b && x.layer_id === l.id);
        const v = r ? r[field] : null;
        point[layerKey(l.id)] = v == null ? null : round(v, 1);
        if (v != null) vals.push(v);
      }
      point.farm = vals.length ? round(name === 'water_usage' ? sum(vals) : avg(vals), 1) : null;
      return point;
    });
  }
  return { range, granularity: gran, layers: layers.map((l) => ({ id: l.id, key: layerKey(l.id), name: l.layer_name, crop: l.crop_type })), series: out };
}

/** Layer-vs-layer averages for the chosen window. */
export async function comparison(layers, range) {
  const win = await loadWindow(layers, windowFor(range));
  const rows = layers.map((l) => {
    const sub = { ...win, readings: win.readings.filter((r) => r.layer_id === l.id), irrigation: win.irrigation.filter((r) => r.layer_id === l.id), health: win.health.filter((r) => r.layer_id === l.id), alerts: win.alerts.filter((r) => r.layer_id === l.id) };
    const d = describe(sub);
    return { layerId: l.id, key: layerKey(l.id), name: l.layer_name, crop: l.crop_type, temperature: d.averageTemperature, humidity: d.averageHumidity, soil_moisture: d.averageSoilMoisture, water_usage: d.totalWaterUsage, crop_health: d.averageCropHealth, alerts: d.alertCount };
  });
  return { range, layers: rows };
}

// ---- correlation ----------------------------------------------------------
function pearson(xs, ys) {
  const pairs = xs.map((x, i) => [x, ys[i]]).filter(([x, y]) => x != null && y != null);
  const n = pairs.length;
  if (n < 3) return { r: null, n };
  const mx = avg(pairs.map((p) => p[0])), my = avg(pairs.map((p) => p[1]));
  let num = 0, dx = 0, dy = 0;
  for (const [x, y] of pairs) { num += (x - mx) * (y - my); dx += (x - mx) ** 2; dy += (y - my) ** 2; }
  if (dx === 0 || dy === 0) return { r: null, n };
  return { r: round(num / Math.sqrt(dx * dy), 2), n };
}
const strength = (r) => { const a = Math.abs(r); return a < 0.2 ? 'very weakly' : a < 0.4 ? 'weakly' : a < 0.6 ? 'moderately' : a < 0.8 ? 'strongly' : 'very strongly'; };
const NAMES = { temperature: 'temperature', humidity: 'humidity', soil_moisture: 'soil moisture', water_usage: 'water usage', crop_health: 'crop health' };

function explain(x, y, r) {
  if (r == null) return 'Not enough varied data to measure this relationship yet.';
  if (Math.abs(r) < 0.2) return `There is almost no linear relationship between ${NAMES[x]} and ${NAMES[y]} in this data.`;
  const dir = r > 0 ? 'higher' : 'lower';
  return `Higher ${NAMES[x]} is ${strength(r)} associated with ${dir} ${NAMES[y]}.`;
}

/** Pearson correlation on daily per-layer values over the last 30 days. */
export async function correlation(layers) {
  const win = await loadWindow(layers, windowFor('30d'));
  const rows = buildTable(win, 'day').filter((r) => r.crop_health != null);
  const fields = ['temperature', 'humidity', 'soil_moisture', 'water_usage', 'crop_health'];
  const matrix = fields.map((a) => fields.map((b) => (a === b ? 1 : pearson(rows.map((r) => r[a]), rows.map((r) => r[b])).r)));
  const pair = (x, y) => { const { r, n } = pearson(rows.map((q) => q[x]), rows.map((q) => q[y])); return { x, y, r, n, strength: r == null ? null : strength(r), explanation: explain(x, y, r) }; };
  return {
    basis: 'Daily per-layer averages over the last 30 days',
    labels: fields.map((f) => NAMES[f]),
    fields,
    matrix,
    highlights: [pair('soil_moisture', 'crop_health'), pair('temperature', 'crop_health'), pair('water_usage', 'crop_health')],
    note: 'Correlation does not necessarily mean causation. These values show how two measurements move together, not that one causes the other.',
  };
}

export { SENSOR_META, SEVERITY_ORDER, HOURS, bucketKey };
