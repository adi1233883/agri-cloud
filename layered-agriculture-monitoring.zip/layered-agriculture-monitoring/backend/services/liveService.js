import { repo } from '../db/index.js';
import { runtime } from '../models/runtime.js';
import { evaluateRules, SEVERITY_ORDER } from '../config/agri.js';

/** Latest value of every sensor type per layer. Uses the live simulator when running, else the newest DB rows. */
export async function getLatestValues(layers) {
  const snap = runtime.simulator?.snapshot();
  if (snap) return { mode: 'simulator', updatedAt: snap.updatedAt, values: snap.values };

  const ids = layers.map((l) => l.id);
  const sensors = await repo.list('sensors', { in: { layer_id: ids } });
  const since = new Date(Date.now() - 6 * 3600e3).toISOString();
  const rows = sensors.length
    ? await repo.list('sensor_readings', { gte: { timestamp: since }, in: { sensor_id: sensors.map((s) => s.id) }, order: ['timestamp', 'asc'] })
    : [];
  const bySensor = new Map(sensors.map((s) => [s.id, s]));
  const values = {};
  let updatedAt = null;
  for (const r of rows) {
    const s = bySensor.get(r.sensor_id);
    (values[s.layer_id] ||= {})[s.sensor_type] = Number(r.value); // later rows overwrite earlier ones
    updatedAt = r.timestamp;
  }
  return { mode: 'database', updatedAt, values };
}

/** Plain-language condition of a layer, from live values and its active alerts. */
export function layerCondition(values = {}, alerts = []) {
  const crit = alerts.some((a) => a.severity === 'critical');
  if (crit) return 'Critical';
  if (values.soil_moisture != null && values.soil_moisture < 36) return 'Needs Irrigation';
  if (alerts.some((a) => a.severity === 'warning')) return 'Attention';
  return 'Healthy';
}

export { evaluateRules, SEVERITY_ORDER };
