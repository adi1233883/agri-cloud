import { repo } from '../db/index.js';
import { flowRate } from '../config/agri.js';
import { runtime } from '../models/runtime.js';
import { AppError } from '../middleware/error.js';
import { windowFor, loadWindow, buildTable, sum } from '../models/timeseries.js';
import { getLatestValues } from './liveService.js';

export async function overview(layers) {
  const ids = layers.map((l) => l.id);
  const [recent, month, latest] = await Promise.all([
    repo.list('irrigation', { in: { layer_id: ids }, order: ['timestamp', 'desc'], limit: 15 }),
    repo.list('irrigation', { in: { layer_id: ids }, gte: { timestamp: windowFor('30d').start.toISOString() }, order: ['timestamp', 'asc'] }),
    getLatestValues(layers),
  ]);
  const within = (h) => month.filter((r) => new Date(r.timestamp).getTime() >= Date.now() - h * 3600e3);
  const dayRows = within(24), weekRows = within(168);

  const perLayer = layers.map((l) => {
    const running = month.find((r) => r.layer_id === l.id && r.status === 'running') || recent.find((r) => r.layer_id === l.id && r.status === 'running');
    const rows = month.filter((r) => r.layer_id === l.id);
    const last = [...rows].reverse().find((r) => r.status !== 'running');
    const v = latest.values[l.id] || {};
    return {
      layerId: l.id, name: l.layer_name, crop: l.crop_type, status: running ? 'running' : 'idle', flowLitresPerMin: flowRate(l.area),
      soilMoisture: v.soil_moisture ?? null, tankLevel: v.water_level ?? null,
      today: sum(dayRows.filter((r) => r.layer_id === l.id).map((r) => r.water_used)),
      week: sum(weekRows.filter((r) => r.layer_id === l.id).map((r) => r.water_used)),
      month: sum(rows.map((r) => r.water_used)),
      sessionsMonth: rows.length,
      lastRun: last ? { timestamp: last.timestamp, duration: last.duration, waterUsed: last.water_used } : null,
      runningSince: running?.timestamp ?? null,
    };
  });

  const daily = buildTable(await loadWindow(layers, windowFor('30d')), 'day');
  const days = [...new Set(daily.map((r) => r.bucket))].sort();
  const chart = days.map((d) => {
    const p = { t: d };
    for (const l of layers) p[`L${l.id}`] = daily.find((r) => r.bucket === d && r.layer_id === l.id)?.water_usage ?? 0;
    return p;
  });
  return {
    simulated: true,
    totals: { today: sum(dayRows.map((r) => r.water_used)), week: sum(weekRows.map((r) => r.water_used)), month: sum(month.map((r) => r.water_used)),
      durationToday: sum(dayRows.map((r) => r.duration)), activeZones: perLayer.filter((p) => p.status === 'running').length },
    layers: perLayer,
    chart,
    recent: recent.map((r) => ({ ...r, layer: layers.find((l) => l.id === r.layer_id)?.layer_name })),
  };
}

export async function start(layer) {
  if (runtime.running.has(layer.id)) throw new AppError(409, `${layer.layer_name} is already being irrigated.`);
  const latest = await getLatestValues([layer]);
  const tank = latest.values[layer.id]?.water_level;
  if (tank != null && tank < 5) throw new AppError(409, 'The water tank is almost empty. Refill it before irrigating.');
  const row = await repo.insert('irrigation', { layer_id: layer.id, water_used: 0, duration: 0, status: 'running', timestamp: new Date().toISOString() });
  runtime.running.set(layer.id, row.id);
  return row;
}

export async function stop(layer) {
  const id = runtime.running.get(layer.id);
  if (!id) throw new AppError(409, `${layer.layer_name} is not being irrigated right now.`);
  const row = await repo.update('irrigation', id, { status: 'stopped' });
  runtime.running.delete(layer.id);
  return row;
}
