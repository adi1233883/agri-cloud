import jwt from 'jsonwebtoken';
import { config, useSupabase } from '../config/index.js';
import { repo, supabase } from '../db/index.js';
import { AppError, asyncHandler } from './error.js';

// Demo-mode accounts (only used when Supabase is NOT configured).
export const DEMO_USERS = [
  { id: 'demo-admin', email: 'admin@agri.demo', password: 'Admin@123', name: 'Farm Admin', role: 'admin' },
  { id: 'demo-viewer', email: 'viewer@agri.demo', password: 'Viewer@123', name: 'Farm Viewer', role: 'viewer' },
];

export const signDemoToken = (u) =>
  jwt.sign({ sub: u.id, email: u.email, name: u.name, role: u.role }, config.demoJwtSecret, { expiresIn: '12h' });

export const authenticate = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) throw new AppError(401, 'Please sign in to continue.');

  if (useSupabase) {
    const { data, error } = await supabase.auth.getUser(token); // verified by Supabase Auth
    if (error || !data?.user) throw new AppError(401, 'Your session has expired. Please sign in again.');
    const profile = (await repo.list('users', { eq: { id: data.user.id } }))[0];
    req.user = {
      id: data.user.id,
      email: data.user.email,
      name: profile?.name || data.user.email.split('@')[0],
      role: profile?.role || 'viewer',
    };
  } else {
    try {
      const p = jwt.verify(token, config.demoJwtSecret);
      req.user = { id: p.sub, email: p.email, name: p.name, role: p.role };
    } catch {
      throw new AppError(401, 'Your session has expired. Please sign in again.');
    }
  }
  next();
});

export const requireAdmin = (req, res, next) =>
  req.user?.role === 'admin' ? next() : next(new AppError(403, 'Only admins can do this.'));
