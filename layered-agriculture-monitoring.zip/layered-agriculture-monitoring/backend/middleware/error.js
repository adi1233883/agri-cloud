export class AppError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
export const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
export const notFound = (req, res) => res.status(404).json({ error: `Route not found: ${req.method} ${req.originalUrl}` });
// eslint-disable-next-line no-unused-vars
export const errorHandler = (err, req, res, next) => {
  const status = err.status || 500;
  if (status >= 500) console.error('[error]', err.message);
  res.status(status).json({ error: status >= 500 && !err.status ? 'Internal server error' : err.message });
};

export const RANGES = ['today', '7d', '30d'];
export function parseRange(value, fallback = '7d') {
  if (value == null || value === '') return fallback;
  if (!RANGES.includes(value)) throw new AppError(400, `Invalid range "${value}". Use one of: ${RANGES.join(', ')}.`);
  return value;
}
export function parseId(value, name = 'id') {
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) throw new AppError(400, `Invalid ${name}.`);
  return n;
}
