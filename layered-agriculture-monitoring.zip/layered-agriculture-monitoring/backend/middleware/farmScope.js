import { repo } from '../db/index.js';
import { AppError, asyncHandler } from './error.js';

// Resolves ?farm_id= (default: first farm) and attaches the farm and its layers to the request.
export const farmScope = asyncHandler(async (req, res, next) => {
  const farms = await repo.list('farms');
  if (!farms.length) throw new AppError(404, 'No farms found. Run the database seed first.');
  const wanted = req.query.farm_id ? Number(req.query.farm_id) : farms[0].id;
  const farm = farms.find((f) => f.id === wanted);
  if (!farm) throw new AppError(404, 'Farm not found.');
  req.farm = farm;
  req.layers = await repo.list('layers', { eq: { farm_id: farm.id } });
  next();
});
