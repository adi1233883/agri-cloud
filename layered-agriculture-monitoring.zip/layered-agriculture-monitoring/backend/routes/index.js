import { Router } from 'express';
import { authenticate, requireAdmin } from '../middleware/auth.js';
import { farmScope } from '../middleware/farmScope.js';
import * as auth from '../controllers/auth.js';
import * as layers from '../controllers/layers.js';
import * as readings from '../controllers/readings.js';
import * as analytics from '../controllers/analytics.js';
import * as ops from '../controllers/operations.js';
import { asyncHandler } from '../middleware/error.js';

const r = Router();

// public
r.get('/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));
r.get('/auth/mode', auth.mode);
r.get('/auth/demo-credentials', auth.demoCredentials);
r.post('/auth/login', auth.demoLogin);
r.post('/readings/ingest', readings.ingest); // protected by X-Device-Key

// everything below requires a signed-in user
r.use(authenticate);
r.get('/auth/me', auth.me);
r.get('/farms', ops.listFarms);
r.use(farmScope);

r.get('/layers', layers.list);
r.post('/layers', requireAdmin, layers.create);
r.get('/layers/:id', layers.detail);
r.get('/sensors', layers.listSensors);
r.post('/sensors', requireAdmin, layers.addSensor);
r.get('/crops', layers.crops);

r.get('/live', readings.live);
r.get('/readings', readings.all);
r.get('/readings/:layerId', readings.byLayer);

r.get('/dashboard/stats', analytics.dashboard);
r.get('/analytics', analytics.overview);
r.get('/analytics/summary', analytics.summary);
r.get('/analytics/trends', analytics.trends);
r.get('/analytics/comparison', analytics.comparison);
r.get('/analytics/correlation', analytics.correlation);
r.get('/analytics/insights', analytics.insights);
r.get('/analytics/:layerId', analytics.overview);

r.get('/alerts', ops.listAlerts);
r.post('/alerts/:id/resolve', requireAdmin, ops.resolve);

r.get('/irrigation', ops.irrigationOverview);
r.post('/irrigation/start', requireAdmin, ops.irrigationStart);
r.post('/irrigation/stop', requireAdmin, ops.irrigationStop);

r.get('/crop-health', ops.cropHealth);
r.get('/reports', ops.report);
r.get('/export/csv', ops.exportCsv);

export default r;
