// Tiny shared runtime state: which layers are being irrigated right now (layerId -> irrigation row id).
export const runtime = { running: new Map(), simulator: null };
