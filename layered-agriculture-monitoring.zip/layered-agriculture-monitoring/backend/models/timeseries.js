// Helpers that load a time window of data and bucket it for charts, reports and CSV export.
import { repo } from '../db/index.js';

export const HOURS = { today: 24, '7d': 168, '30d': 720 };
export const GRANULARITY = { today: 'hour', '7d': '6h', '30d': 'day' };
const HOUR_MS = 3600e3;

export function windowFor(range, offset = 0) {
  const end = Date.now() - offset * HOURS[range] * HOUR_MS;
  return { start: new Date(end - HOURS[range] * HOUR_MS), end: new Date(end) };
}

export function bucketKey(ts, gran) {
  const d = new Date(ts);
  const day = d.toISOString().slice(0, 10);
  if (gran === 'day') return `${day}T00:00:00.000Z`;
  const h = d.getUTCHours();
  const hh = gran === '6h' ? Math.floor(h / 6) * 6 : h;
  return `${day}T${String(hh).padStart(2, '0')}:00:00.000Z`;
}

/** Load sensors/readings/irrigation/health/alerts for the given layers within [start, end]. */
export async function loadWindow(layers, { start, end }) {
  const layerIds = layers.map((l) => l.id);
  if (!layerIds.length) return { layers, sensors: [], readings: [], irrigation: [], health: [], alerts: [] };
  const sensors = await repo.list('sensors', { in: { layer_id: layerIds } });
  const sensorMap = new Map(sensors.map((s) => [s.id, s]));
  const range = { gte: { timestamp: start.toISOString() }, lte: { timestamp: end.toISOString() }, order: ['timestamp', 'asc'] };
  const [rawReadings, irrigation, health, alerts] = await Promise.all([
    sensors.length ? repo.list('sensor_readings', { ...range, in: { sensor_id: sensors.map((s) => s.id) } }) : [],
    repo.list('irrigation', { ...range, in: { layer_id: layerIds } }),
    repo.list('crop_health', { ...range, in: { layer_id: layerIds } }),
    repo.list('alerts', { ...range, in: { layer_id: layerIds } }),
  ]);
  const readings = rawReadings.map((r) => {
    const s = sensorMap.get(r.sensor_id);
    return { layer_id: s.layer_id, type: s.sensor_type, value: Number(r.value), timestamp: r.timestamp };
  });
  return { layers, sensors, readings, irrigation, health, alerts };
}

const METRICS = ['temperature', 'humidity', 'soil_moisture', 'soil_ph', 'light'];

/** Rows per (bucket, layer): averaged sensor metrics, summed water use, averaged crop health. */
export function buildTable(win, gran) {
  const acc = new Map();
  const row = (bucket, layer_id) => {
    const key = `${bucket}|${layer_id}`;
    if (!acc.has(key)) acc.set(key, { bucket, layer_id, sums: {}, counts: {}, water: 0, hSum: 0, hCount: 0 });
    return acc.get(key);
  };
  for (const r of win.readings) {
    if (!METRICS.includes(r.type)) continue;
    const a = row(bucketKey(r.timestamp, gran), r.layer_id);
    a.sums[r.type] = (a.sums[r.type] || 0) + r.value;
    a.counts[r.type] = (a.counts[r.type] || 0) + 1;
  }
  for (const w of win.irrigation) row(bucketKey(w.timestamp, gran), w.layer_id).water += Number(w.water_used) || 0;
  for (const h of win.health) {
    const a = row(bucketKey(h.timestamp, gran), h.layer_id);
    a.hSum += Number(h.health_score);
    a.hCount += 1;
  }
  const rows = [...acc.values()].map((a) => {
    const out = { bucket: a.bucket, layer_id: a.layer_id, water_usage: Math.round(a.water), crop_health: a.hCount ? a.hSum / a.hCount : null };
    for (const m of METRICS) out[m] = a.counts[m] ? a.sums[m] / a.counts[m] : null;
    return out;
  });
  rows.sort((x, y) => (x.bucket > y.bucket ? 1 : x.bucket < y.bucket ? -1 : x.layer_id - y.layer_id));

  // carry the last known crop-health score forward so charts have no gaps between daily inspections
  const last = {};
  const sortedHealth = [...win.health].sort((a, b) => (a.timestamp > b.timestamp ? 1 : -1));
  for (const r of rows) {
    if (r.crop_health != null) { last[r.layer_id] = r.crop_health; continue; }
    const prior = sortedHealth.filter((h) => h.layer_id === r.layer_id && bucketKey(h.timestamp, gran) < r.bucket).pop();
    r.crop_health = last[r.layer_id] ?? (prior ? Number(prior.health_score) : null);
  }
  return rows;
}

export const avg = (xs) => { const v = xs.filter((x) => x != null && !Number.isNaN(x)); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null; };
export const sum = (xs) => xs.reduce((a, b) => a + (Number(b) || 0), 0);
export const round = (x, d = 1) => (x == null ? null : Math.round(x * 10 ** d) / 10 ** d);
export const pct = (cur, prev) => (cur == null || prev == null || prev === 0 ? null : round(((cur - prev) / Math.abs(prev)) * 100, 1));
