import express from 'express';
import cors from 'cors';
import { config, useSupabase } from './config/index.js';
import routes from './routes/index.js';
import { notFound, errorHandler } from './middleware/error.js';
import { Simulator } from './simulator/index.js';
import { runtime } from './models/runtime.js';

const app = express();
app.disable('x-powered-by');
app.use(cors({ origin: (origin, cb) => cb(null, !origin || config.corsOrigins.includes('*') || config.corsOrigins.includes(origin)), credentials: true }));
app.use(express.json({ limit: '100kb' }));
app.get('/', (req, res) => res.json({ name: 'Layered Agriculture Monitoring API', docs: '/api/health' }));
app.use('/api', routes);
app.use(notFound);
app.use(errorHandler);

const server = app.listen(config.port, async () => {
  console.log(`API listening on :${config.port}  |  database: ${useSupabase ? 'Supabase (cloud)' : 'in-memory demo'}`);
  if (config.sim.enabled) {
    runtime.simulator = new Simulator();
    try { await runtime.simulator.start(); } catch (e) { console.error('[simulator] failed to start:', e.message); runtime.simulator = null; }
  }
});
const shutdown = () => { runtime.simulator?.stop(); server.close(() => process.exit(0)); };
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
