import { repo } from '../db/index.js';
import { config } from '../config/index.js';
import { AppError, asyncHandler, parseId, parseRange } from '../middleware/error.js';
import { windowFor } from '../models/timeseries.js';
import { getLatestValues } from '../services/liveService.js';
import { evaluateLayer } from '../services/alertService.js';
import { SENSOR_META } from '../config/agri.js';

async function readingsFor(layers, { range, limit }) {
  const sensors = await repo.list('sensors', { in: { layer_id: layers.map((l) => l.id) } });
  if (!sensors.length) return [];
  const byId = new Map(sensors.map((s) => [s.id, s]));
  const opts = { in: { sensor_id: sensors.map((s) => s.id) }, order: ['timestamp', 'desc'], limit };
  if (range) opts.gte = { timestamp: windowFor(range).start.toISOString() };
  const rows = await repo.list('sensor_readings', opts);
  return rows.map((r) => { const s = byId.get(r.sensor_id); return { id: r.id, timestamp: r.timestamp, value: Number(r.value), sensor_id: r.sensor_id, sensor_type: s.sensor_type, unit: s.unit, layer_id: s.layer_id }; });
}
const cap = (v, dflt) => Math.min(Math.max(Number(v) || dflt, 1), 2000);

export const all = asyncHandler(async (req, res) => res.json(await readingsFor(req.layers, { limit: cap(req.query.limit, 200) })));

export const byLayer = asyncHandler(async (req, res) => {
  const id = parseId(req.params.layerId, 'layer id');
  const layer = req.layers.find((l) => l.id === id);
  if (!layer) throw new AppError(404, 'Layer not found.');
  const range = req.query.range ? parseRange(req.query.range) : null;
  res.json(await readingsFor([layer], { range, limit: cap(req.query.limit, 500) }));
});

export const live = asyncHandler(async (req, res) => {
  const latest = await getLatestValues(req.layers);
  res.json({ mode: latest.mode, updatedAt: latest.updatedAt, layers: req.layers.map((l) => ({ id: l.id, name: l.layer_name, crop: l.crop_type, values: latest.values[l.id] || {} })) });
});

// IoT ingestion: a real device (e.g. ESP32) can POST readings here instead of the simulator.
export const ingest = asyncHandler(async (req, res) => {
  if (!config.deviceApiKey || req.headers['x-device-key'] !== config.deviceApiKey) throw new AppError(401, 'Invalid device key.');
  const { sensor_id, value } = req.body || {};
  const sensor = await repo.get('sensors', Number(sensor_id));
  if (!sensor) throw new AppError(404, 'Unknown sensor.');
  const v = Number(value);
  const [lo, hi] = SENSOR_META[sensor.sensor_type].range;
  if (!Number.isFinite(v) || v < lo - 50 * (hi - lo) || v > hi + 50 * (hi - lo)) throw new AppError(400, 'Reading is not a valid number for this sensor.');
  const row = await repo.insert('sensor_readings', { sensor_id: sensor.id, value: v, timestamp: new Date().toISOString() });
  const siblings = await repo.list('sensors', { eq: { layer_id: sensor.layer_id } });
  const latest = {};
  for (const s of siblings) { const r = (await repo.list('sensor_readings', { eq: { sensor_id: s.id }, order: ['timestamp', 'desc'], limit: 1 }))[0]; if (r) latest[s.sensor_type] = Number(r.value); }
  await evaluateLayer(sensor.layer_id, latest);
  res.status(201).json(row);
});
