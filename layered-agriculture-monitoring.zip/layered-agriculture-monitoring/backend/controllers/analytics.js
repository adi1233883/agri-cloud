import { repo } from '../db/index.js';
import { AppError, asyncHandler, parseId, parseRange } from '../middleware/error.js';
import * as svc from '../services/analyticsService.js';
import { generateInsights } from '../services/insightService.js';
import { getLatestValues, layerCondition } from '../services/liveService.js';
import { runtime } from '../models/runtime.js';
import { SEVERITY_ORDER } from '../config/agri.js';

const scoped = (req) => {
  if (!req.params.layerId) return req.layers;
  const layer = req.layers.find((l) => l.id === parseId(req.params.layerId, 'layer id'));
  if (!layer) throw new AppError(404, 'Layer not found.');
  return [layer];
};

export const summary = asyncHandler(async (req, res) => res.json(await svc.summary(scoped(req), parseRange(req.query.range, 'today'))));
export const trends = asyncHandler(async (req, res) => res.json(await svc.trends(scoped(req), parseRange(req.query.range))));
export const comparison = asyncHandler(async (req, res) => res.json(await svc.comparison(req.layers, parseRange(req.query.range))));
export const correlation = asyncHandler(async (req, res) => res.json(await svc.correlation(req.layers)));
export const insights = asyncHandler(async (req, res) => res.json(await generateInsights(req.layers)));

// Everything analytics for one range in one call (used by the Analytics page)
export const overview = asyncHandler(async (req, res) => {
  const layers = scoped(req);
  const range = parseRange(req.query.range);
  const [summary, trends, comparison, correlation, insights] = await Promise.all([
    svc.summary(layers, range), svc.trends(layers, range), svc.comparison(req.layers, range), svc.correlation(req.layers), generateInsights(req.layers),
  ]);
  res.json({ summary, trends, comparison, correlation, insights });
});

export const dashboard = asyncHandler(async (req, res) => {
  const [s, t, latest, insights] = await Promise.all([svc.summary(req.layers, 'today'), svc.trends(req.layers, 'today'), getLatestValues(req.layers), generateInsights(req.layers)]);
  const ids = req.layers.map((l) => l.id);
  const active = await repo.list('alerts', { eq: { status: 'active' }, in: { layer_id: ids }, order: ['timestamp', 'desc'] });
  const healthNow = [];
  for (const l of req.layers) { const h = (await repo.list('crop_health', { eq: { layer_id: l.id }, order: ['timestamp', 'desc'], limit: 1 }))[0]; if (h) healthNow.push(Number(h.health_score)); }
  const cropHealth = healthNow.length ? Math.round((healthNow.reduce((a, b) => a + b, 0) / healthNow.length) * 10) / 10 : null;
  const spark = (key) => t.series[key].map((p) => p.farm);
  const liveAvg = (type) => { const v = req.layers.map((l) => latest.values[l.id]?.[type]).filter((x) => x != null); return v.length ? Math.round((v.reduce((a, b) => a + b, 0) / v.length) * 10) / 10 : null; };

  res.json({
    farm: req.farm, updatedAt: latest.updatedAt, dataSource: latest.mode,
    kpis: {
      temperature: { label: 'Average Temperature', value: liveAvg('temperature') ?? s.averageTemperature, unit: '°C', change: s.change.averageTemperature, spark: spark('temperature') },
      soilMoisture: { label: 'Average Soil Moisture', value: liveAvg('soil_moisture') ?? s.averageSoilMoisture, unit: '%', change: s.change.averageSoilMoisture, spark: spark('soil_moisture') },
      cropHealth: { label: 'Crop Health', value: cropHealth, unit: '%', change: s.change.averageCropHealth, spark: spark('crop_health') },
      water: { label: 'Water Consumption', value: s.totalWaterUsage, unit: 'L', change: s.change.totalWaterUsage, spark: spark('water_usage'), note: 'last 24 h' },
      light: { label: 'Light Intensity', value: liveAvg('light') ?? s.averageLight, unit: 'lux', change: s.change.averageLight, spark: spark('light') },
      alerts: { label: 'Active Alerts', value: active.length, unit: '', change: s.change.alertCount, spark: null },
    },
    layers: req.layers.map((l) => ({ id: l.id, name: l.layer_name, crop: l.crop_type, values: latest.values[l.id] || {}, condition: layerCondition(latest.values[l.id], active.filter((a) => a.layer_id === l.id)), irrigating: runtime.running.has(l.id) })),
    alerts: active.sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity] || (a.timestamp < b.timestamp ? 1 : -1)).slice(0, 5).map((a) => ({ ...a, layer: req.layers.find((l) => l.id === a.layer_id)?.layer_name })),
    insights: insights.slice(0, 4),
    trend: { temperature: t.series.temperature, soil_moisture: t.series.soil_moisture, layers: t.layers },
  });
});
