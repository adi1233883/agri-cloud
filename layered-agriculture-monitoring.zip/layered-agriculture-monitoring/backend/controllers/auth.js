import { config, useSupabase } from '../config/index.js';
import { AppError, asyncHandler } from '../middleware/error.js';
import { DEMO_USERS, signDemoToken } from '../middleware/auth.js';

export const mode = (req, res) => res.json({ auth: useSupabase ? 'supabase' : 'demo', database: useSupabase ? 'supabase' : 'memory' });

// Only used in demo mode. With Supabase configured, the frontend signs in directly with Supabase Auth.
export const demoLogin = (req, res) => {
  if (useSupabase) throw new AppError(400, 'This server uses Supabase Auth. Sign in with Supabase from the app.');
  const { email, password } = req.body || {};
  if (!email || !password) throw new AppError(400, 'Enter your email and password.');
  const user = DEMO_USERS.find((u) => u.email.toLowerCase() === String(email).toLowerCase() && u.password === password);
  if (!user) throw new AppError(401, 'Incorrect email or password.');
  res.json({ token: signDemoToken(user), user: { id: user.id, email: user.email, name: user.name, role: user.role } });
};

export const me = (req, res) => res.json({ user: req.user });
export const demoCredentials = (req, res) => res.json(useSupabase ? [] : DEMO_USERS.map(({ email, password, role }) => ({ email, password, role })));
export { config, asyncHandler };
