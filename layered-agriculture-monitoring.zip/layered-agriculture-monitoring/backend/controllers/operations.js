import { repo } from '../db/index.js';
import { AppError, asyncHandler, parseId } from '../middleware/error.js';
import { SEVERITY_ORDER, profileFor } from '../config/agri.js';
import { resolveAlert } from '../services/alertService.js';
import * as irrigation from '../services/irrigationService.js';
import { buildReport, buildCsv, REPORT_METRICS } from '../services/reportService.js';
import { parseRange } from '../middleware/error.js';
import { windowFor } from '../models/timeseries.js';

// ---- alerts
export const listAlerts = asyncHandler(async (req, res) => {
  const { status, severity } = req.query;
  if (status && !['active', 'resolved'].includes(status)) throw new AppError(400, 'status must be "active" or "resolved".');
  if (severity && !(severity in SEVERITY_ORDER)) throw new AppError(400, 'severity must be critical, warning or info.');
  const rows = await repo.list('alerts', { in: { layer_id: req.layers.map((l) => l.id) }, ...(status ? { eq: { status } } : {}), order: ['timestamp', 'desc'], limit: 300 });
  const out = rows.filter((a) => !severity || a.severity === severity).map((a) => ({ ...a, layer: req.layers.find((l) => l.id === a.layer_id)?.layer_name }));
  out.sort((a, b) => (a.status === b.status ? SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity] || (a.timestamp < b.timestamp ? 1 : -1) : a.status === 'active' ? -1 : 1));
  res.json(out);
});

export const resolve = asyncHandler(async (req, res) => {
  const alert = await repo.get('alerts', parseId(req.params.id, 'alert id'));
  if (!alert || !req.layers.some((l) => l.id === alert.layer_id)) throw new AppError(404, 'Alert not found.');
  res.json(await resolveAlert(alert.id));
});

// ---- irrigation
export const irrigationOverview = asyncHandler(async (req, res) => res.json(await irrigation.overview(req.layers)));
const layerFromBody = (req) => {
  const layer = req.layers.find((l) => l.id === Number(req.body?.layer_id));
  if (!layer) throw new AppError(400, 'Choose a layer from this farm.');
  return layer;
};
export const irrigationStart = asyncHandler(async (req, res) => res.status(201).json(await irrigation.start(layerFromBody(req))));
export const irrigationStop = asyncHandler(async (req, res) => res.json(await irrigation.stop(layerFromBody(req))));

// ---- crop health
export const cropHealth = asyncHandler(async (req, res) => {
  const since = windowFor('30d').start.toISOString();
  const rows = await repo.list('crop_health', { in: { layer_id: req.layers.map((l) => l.id) }, gte: { timestamp: since }, order: ['timestamp', 'asc'] });
  res.json(req.layers.map((l) => {
    const h = rows.filter((r) => r.layer_id === l.id);
    const last = h[h.length - 1];
    return {
      layerId: l.id, layer: l.layer_name, crop: l.crop_type, preferred: profileFor(l.crop_type),
      healthScore: last ? Number(last.health_score) : null, diseaseRisk: last?.disease_risk ?? null, growth: last?.growth_status ?? null,
      lastInspection: last?.timestamp ?? null,
      history: h.filter((_, i) => i % 1 === 0).slice(-30).map((r) => ({ t: r.timestamp, score: Number(r.health_score) })),
    };
  }));
});

// ---- reports & export
export const report = asyncHandler(async (req, res) => {
  const range = parseRange(req.query.range, '7d');
  const layer = req.query.layer_id && req.query.layer_id !== 'all' ? req.layers.find((l) => l.id === Number(req.query.layer_id)) : null;
  if (req.query.layer_id && req.query.layer_id !== 'all' && !layer) throw new AppError(404, 'Layer not found.');
  const metrics = (req.query.metrics ? String(req.query.metrics).split(',') : REPORT_METRICS).filter((m) => REPORT_METRICS.includes(m));
  if (!metrics.length) throw new AppError(400, `Choose at least one metric: ${REPORT_METRICS.join(', ')}.`);
  res.json(await buildReport(req.layers, layer, range, metrics));
});

export const exportCsv = asyncHandler(async (req, res) => {
  const range = parseRange(req.query.range, '7d');
  const layer = req.query.layer_id && req.query.layer_id !== 'all' ? req.layers.find((l) => l.id === Number(req.query.layer_id)) : null;
  const csv = await buildCsv(req.layers, layer, range);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="agri-report-${range}-${new Date().toISOString().slice(0, 10)}.csv"`);
  res.send(csv);
});

export const listFarms = asyncHandler(async (req, res) => res.json(await repo.list('farms')));
