import { repo } from '../db/index.js';
import { SENSOR_META, profileFor } from '../config/agri.js';
import { AppError, asyncHandler, parseId } from '../middleware/error.js';
import { runtime } from '../models/runtime.js';
import { getLatestValues, layerCondition } from '../services/liveService.js';
import { trends } from '../services/analyticsService.js';
import { SEVERITY_ORDER } from '../config/agri.js';

async function enrich(layers) {
  const ids = layers.map((l) => l.id);
  const [latest, alerts, sensors] = await Promise.all([
    getLatestValues(layers),
    repo.list('alerts', { eq: { status: 'active' }, in: { layer_id: ids } }),
    repo.list('sensors', { in: { layer_id: ids } }),
  ]);
  const health = await Promise.all(layers.map((l) => repo.list('crop_health', { eq: { layer_id: l.id }, order: ['timestamp', 'desc'], limit: 1 }).then((r) => r[0] || null)));
  return layers.map((l, i) => {
    const values = latest.values[l.id] || {};
    const la = alerts.filter((a) => a.layer_id === l.id).sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity]);
    return {
      ...l, values, condition: layerCondition(values, la), activeAlerts: la.length, irrigating: runtime.running.has(l.id),
      sensorCount: sensors.filter((s) => s.layer_id === l.id).length, health: health[i], updatedAt: latest.updatedAt, dataSource: latest.mode,
    };
  });
}

export const list = asyncHandler(async (req, res) => res.json({ farm: req.farm, layers: await enrich(req.layers) }));

export const detail = asyncHandler(async (req, res) => {
  const id = parseId(req.params.id, 'layer id');
  const layer = req.layers.find((l) => l.id === id);
  if (!layer) throw new AppError(404, 'Layer not found.');
  const [enriched] = await enrich([layer]);
  const [sensors, alerts, irrigation, healthHistory, trend] = await Promise.all([
    repo.list('sensors', { eq: { layer_id: id } }),
    repo.list('alerts', { eq: { layer_id: id }, order: ['timestamp', 'desc'], limit: 10 }),
    repo.list('irrigation', { eq: { layer_id: id }, order: ['timestamp', 'desc'], limit: 8 }),
    repo.list('crop_health', { eq: { layer_id: id }, order: ['timestamp', 'desc'], limit: 30 }),
    trends([layer], req.query.range === '7d' ? '7d' : 'today'),
  ]);
  res.json({
    layer: enriched,
    sensors: sensors.map((s) => ({ ...s, value: enriched.values[s.sensor_type] ?? null })),
    preferred: profileFor(layer.crop_type),
    alerts, irrigation, healthHistory: healthHistory.reverse(), trend: trend.series,
  });
});

export const create = asyncHandler(async (req, res) => {
  const { layer_name, crop_type, area } = req.body || {};
  const name = String(layer_name || '').trim();
  const crop = String(crop_type || '').trim();
  if (!name || name.length > 80) throw new AppError(400, 'Layer name is required (max 80 characters).');
  if (!crop) throw new AppError(400, 'Crop type is required.');
  const a = Number(area);
  if (!Number.isFinite(a) || a <= 0 || a > 1000) throw new AppError(400, 'Area must be a positive number of hectares.');
  const layer = await repo.insert('layers', { farm_id: req.farm.id, layer_name: name, crop_type: crop, area: a, status: 'active' });
  res.status(201).json(layer);
});

export const listSensors = asyncHandler(async (req, res) => {
  const sensors = await repo.list('sensors', { in: { layer_id: req.layers.map((l) => l.id) } });
  const latest = await getLatestValues(req.layers);
  res.json(sensors.map((s) => ({ ...s, value: latest.values[s.layer_id]?.[s.sensor_type] ?? null })));
});

export const addSensor = asyncHandler(async (req, res) => {
  const { layer_id, sensor_type, sensor_name } = req.body || {};
  const layer = req.layers.find((l) => l.id === Number(layer_id));
  if (!layer) throw new AppError(400, 'Choose a layer from this farm.');
  const meta = SENSOR_META[sensor_type];
  if (!meta) throw new AppError(400, `Unknown sensor type. Use one of: ${Object.keys(SENSOR_META).join(', ')}.`);
  const sensors = await repo.list('sensors', { eq: { layer_id: layer.id } });
  if (sensors.some((s) => s.sensor_type === sensor_type)) throw new AppError(409, `${layer.layer_name} already has a ${meta.label} sensor.`);
  const row = await repo.insert('sensors', { layer_id: layer.id, sensor_type, sensor_name: String(sensor_name || `L${layer.id} ${meta.label} Sensor`).slice(0, 80), unit: meta.unit, status: 'online' });
  res.status(201).json(row);
});

export const crops = asyncHandler(async (req, res) =>
  res.json(req.layers.map((l) => ({ layerId: l.id, layer: l.layer_name, crop: l.crop_type, area: l.area, preferred: profileFor(l.crop_type) }))));
