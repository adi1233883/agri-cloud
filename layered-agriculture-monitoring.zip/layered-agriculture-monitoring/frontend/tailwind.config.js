/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        leaf: { 50: '#f2f9f4', 100: '#e0f1e5', 200: '#c0e2cb', 300: '#94cba7', 400: '#5fae7c', 500: '#34975c', 600: '#257a49', 700: '#1e613b', 800: '#194d31', 900: '#123a25' },
        forest: '#0f2e22',
        mist: '#f5f7f5',
        amber: { 50: '#fff8e6', 100: '#fdeeb8', 500: '#e0a21a', 600: '#b97f0b', 700: '#8f6208' },
        rose: { 50: '#fff1f0', 100: '#ffdcd8', 500: '#d64545', 600: '#b92f2f', 700: '#8f2020' },
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['"Instrument Sans"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      boxShadow: { soft: '0 1px 2px rgba(15,46,34,.05), 0 6px 20px -8px rgba(15,46,34,.12)' },
    },
  },
  plugins: [],
};
