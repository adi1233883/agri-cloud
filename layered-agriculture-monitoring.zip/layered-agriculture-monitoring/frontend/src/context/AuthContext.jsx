import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { supabase } from '../services/supabase';
import { api, setDemoToken, hasDemoToken } from '../services/api';

const AuthCtx = createContext(null);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async () => {
    try { setUser((await api.get('/auth/me')).user); } catch { setUser(null); }
  }, []);

  useEffect(() => {
    (async () => {
      const signedIn = supabase ? Boolean((await supabase.auth.getSession()).data.session) : hasDemoToken();
      if (signedIn) await loadProfile();
      setLoading(false);
    })();
    const onExpired = () => { setDemoToken(null); setUser(null); };
    window.addEventListener('agri:unauthorized', onExpired);
    const sub = supabase?.auth.onAuthStateChange((evt) => { if (evt === 'SIGNED_OUT') setUser(null); });
    return () => { window.removeEventListener('agri:unauthorized', onExpired); sub?.data.subscription.unsubscribe(); };
  }, [loadProfile]);

  const login = async (email, password) => {
    if (supabase) {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw new Error(error.message === 'Invalid login credentials' ? 'Incorrect email or password.' : error.message);
    } else {
      const res = await api.post('/auth/login', { email, password });
      setDemoToken(res.token);
    }
    await loadProfile();
  };

  const signup = async (name, email, password) => {
    if (!supabase) throw new Error('Sign-up needs Supabase. In demo mode, use one of the demo accounts.');
    const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { name } } });
    if (error) throw new Error(error.message);
    if (!data.session) return { needsConfirmation: true };
    await loadProfile();
    return { needsConfirmation: false };
  };

  const logout = async () => {
    if (supabase) await supabase.auth.signOut(); else setDemoToken(null);
    setUser(null);
  };

  return <AuthCtx.Provider value={{ user, loading, login, signup, logout, isAdmin: user?.role === 'admin', cloud: Boolean(supabase) }}>{children}</AuthCtx.Provider>;
}
