import { createContext, useContext, useEffect, useState } from 'react';
import { api, setFarmId } from '../services/api';
import { useAuth } from './AuthContext';

const FarmCtx = createContext(null);
export const useFarm = () => useContext(FarmCtx);

export function FarmProvider({ children }) {
  const { user } = useAuth();
  const [farms, setFarms] = useState([]);
  const [farmId, setId] = useState(null);

  useEffect(() => {
    if (!user) return;
    api.get('/farms').then((f) => { setFarms(f); setFarmId(f[0]?.id ?? null); setId(f[0]?.id ?? null); }).catch(() => {});
  }, [user]);

  const select = (id) => { setFarmId(id); setId(id); };
  return <FarmCtx.Provider value={{ farms, farmId, select, farm: farms.find((f) => f.id === farmId) }}>{farmId ? children : null}</FarmCtx.Provider>;
}
