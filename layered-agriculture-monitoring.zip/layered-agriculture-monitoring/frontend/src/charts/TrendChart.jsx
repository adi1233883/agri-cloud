import { Area, AreaChart, Bar, BarChart, Cell, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { tickLabel, num } from '../utils/format';

/**
 * series: [{ key, name, color, dashed? }]; data: [{ t, [key]: value }]
 * type: 'line' | 'area' | 'bar'; granularity controls x labels.
 */
export default function TrendChart({ data, series, type = 'line', granularity = 'day', unit = '', height = 280, domain, stacked = false }) {
  const common = { data, margin: { top: 8, right: 12, left: -8, bottom: 0 } };
  const axes = [
    <CartesianGrid key="g" strokeDasharray="3 3" stroke="#e8efe9" vertical={false} />,
    <XAxis key="x" dataKey="t" tickFormatter={(v) => tickLabel(v, granularity)} tick={{ fontSize: 11, fill: '#64748b' }} tickLine={false} axisLine={{ stroke: '#e2e8f0' }} minTickGap={28} />,
    <YAxis key="y" domain={domain || ['auto', 'auto']} tick={{ fontSize: 11, fill: '#64748b' }} tickLine={false} axisLine={false} width={48} tickFormatter={(v) => num(v, v % 1 ? 1 : 0)} />,
    <Tooltip key="t" labelFormatter={(v) => new Date(v).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: granularity === 'day' ? undefined : '2-digit', minute: granularity === 'day' ? undefined : '2-digit' })}
      formatter={(v, n) => [`${num(v, 1)} ${unit}`, n]} contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 12 }} />,
    <Legend key="l" iconType="circle" wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />,
  ];
  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer>
        {type === 'bar' ? (
          <BarChart {...common}>{axes}{series.map((s) => <Bar key={s.key} dataKey={s.key} name={s.name} fill={s.color} radius={[4, 4, 0, 0]} stackId={stacked ? 'a' : undefined} maxBarSize={32} />)}</BarChart>
        ) : type === 'area' ? (
          <AreaChart {...common}>{axes}{series.map((s) => <Area key={s.key} type="monotone" dataKey={s.key} name={s.name} stroke={s.color} fill={s.color} fillOpacity={0.14} strokeWidth={2} connectNulls dot={false} />)}</AreaChart>
        ) : (
          <LineChart {...common}>{axes}{series.map((s) => <Line key={s.key} type="monotone" dataKey={s.key} name={s.name} stroke={s.color} strokeWidth={s.dashed ? 2.5 : 2} strokeDasharray={s.dashed ? '6 4' : undefined} dot={false} connectNulls />)}</LineChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}

/** Bar chart of one metric across layers (categorical x-axis). */
export function CompareBars({ rows, metric, unit, height = 260 }) {
  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer>
        <BarChart data={rows} margin={{ top: 8, right: 12, left: -8, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e8efe9" vertical={false} />
          <XAxis dataKey="short" tick={{ fontSize: 12, fill: '#64748b' }} tickLine={false} axisLine={{ stroke: '#e2e8f0' }} />
          <YAxis tick={{ fontSize: 11, fill: '#64748b' }} tickLine={false} axisLine={false} width={48} />
          <Tooltip formatter={(v) => [`${num(v, 1)} ${unit}`, '']} contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 12 }} />
          <Bar dataKey={metric} radius={[6, 6, 0, 0]} maxBarSize={56}>
            {rows.map((r) => <Cell key={r.key} fill={r.color} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
