import { supabase } from './supabase';

const BASE = (import.meta.env.VITE_API_URL || '/api').replace(/\/$/, '');
const DEMO_KEY = 'agri_demo_token';
let farmId = null;

export const setFarmId = (id) => { farmId = id; };
export const setDemoToken = (t) => (t ? localStorage.setItem(DEMO_KEY, t) : localStorage.removeItem(DEMO_KEY));
export const hasDemoToken = () => Boolean(localStorage.getItem(DEMO_KEY));

async function token() {
  if (supabase) return (await supabase.auth.getSession()).data.session?.access_token || null;
  return localStorage.getItem(DEMO_KEY);
}

function url(path) {
  const u = `${BASE}${path}`;
  if (farmId && !path.startsWith('/auth') && !path.startsWith('/farms')) return u + (u.includes('?') ? '&' : '?') + `farm_id=${farmId}`;
  return u;
}

async function request(path, { method = 'GET', body, blob = false } = {}) {
  const t = await token();
  let res;
  try {
    res = await fetch(url(path), {
      method,
      headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(t ? { Authorization: `Bearer ${t}` } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new Error('Cannot reach the server. Check your connection and that the backend is running.');
  }
  if (!res.ok) {
    let msg = `Request failed (${res.status}).`;
    try { msg = (await res.json()).error || msg; } catch { /* not JSON */ }
    if (res.status === 401 && t) window.dispatchEvent(new Event('agri:unauthorized'));
    const err = new Error(msg);
    err.status = res.status;
    throw err;
  }
  return blob ? res.blob() : res.json();
}

export const api = {
  get: (p) => request(p),
  post: (p, body) => request(p, { method: 'POST', body: body || {} }),
  blob: (p) => request(p, { blob: true }),
};

export async function downloadCsv({ range = '7d', layerId = 'all' } = {}) {
  const blob = await api.blob(`/export/csv?range=${range}&layer_id=${layerId}`);
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `agri-report-${range}-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
