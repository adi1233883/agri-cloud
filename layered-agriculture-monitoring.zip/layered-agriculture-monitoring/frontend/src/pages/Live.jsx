import { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUp, Pause, Play } from 'lucide-react';
import { useApi } from '../hooks/useApi';
import { Async, LiveBadge, PageHeader, Sparkline } from '../components/ui';
import { supabase } from '../services/supabase';
import { METRICS, fmtMetric, layerColor, shortLayer, zoneName } from '../utils/format';

const ORDER = ['temperature', 'humidity', 'soil_moisture', 'soil_ph', 'light', 'water_level', 'co2', 'rainfall'];
const MAX_POINTS = 30;

export default function Live() {
  const [paused, setPaused] = useState(false);
  const state = useApi('/live', { interval: paused ? 0 : 4000 });
  const [hist, setHist] = useState({}); // "layer.type" -> [values]
  const prev = useRef({});
  const [deltas, setDeltas] = useState({});

  // keep a short in-browser history so every tile can draw a sparkline
  useEffect(() => {
    const d = state.data;
    if (!d) return;
    const nd = {};
    setHist((h) => {
      const next = { ...h };
      for (const l of d.layers) for (const [t, v] of Object.entries(l.values)) {
        const k = `${l.id}.${t}`;
        const last = prev.current[k];
        nd[k] = last == null ? 0 : v - last;
        prev.current[k] = v;
        next[k] = [...(h[k] || []), v].slice(-MAX_POINTS);
      }
      return next;
    });
    setDeltas((old) => ({ ...old, ...nd }));
  }, [state.data?.updatedAt]); // eslint-disable-line react-hooks/exhaustive-deps

  // Supabase Realtime: refresh as soon as a new reading row lands in the cloud database
  useEffect(() => {
    if (!supabase || paused) return undefined;
    const ch = supabase.channel('readings-live').on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'sensor_readings' }, () => state.refresh()).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [paused]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <>
      <PageHeader title="Live Monitoring" subtitle="Sensor values refresh every few seconds with gradual, realistic changes.">
        <LiveBadge updatedAt={state.data?.updatedAt} paused={paused} />
        <button className="btn-ghost" onClick={() => setPaused((p) => !p)}>{paused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}{paused ? 'Resume' : 'Pause'}</button>
      </PageHeader>
      <Async state={state}>
        {(d) => (
          <>
            <p className="mb-4 text-xs text-slate-500">Source: {d.mode === 'simulator' ? 'sensor simulator (stored in the database every minute)' : 'latest readings from the database'}.</p>
            <div className="space-y-6">
              {d.layers.map((l) => (
                <section key={l.id} className="card overflow-hidden">
                  <div className="flex items-center gap-3 border-b border-slate-100 px-5 py-3.5"><span className="h-3 w-3 rounded-full" style={{ background: layerColor(l.id) }} /><h2 className="text-lg font-bold">{shortLayer(l.name)} · {zoneName(l.name)}</h2><span className="text-sm text-slate-500">{l.crop}</span></div>
                  <div className="grid grid-cols-2 gap-px bg-slate-100 sm:grid-cols-3 lg:grid-cols-4">
                    {ORDER.filter((t) => l.values[t] != null).map((t) => {
                      const k = `${l.id}.${t}`, dlt = deltas[k] || 0;
                      return (
                        <div key={t} className="bg-white p-4">
                          <div className="flex items-center justify-between text-xs font-medium text-slate-500">{METRICS[t].label}
                            {Math.abs(dlt) > 1e-9 && (dlt > 0 ? <ArrowUp className="h-3.5 w-3.5 text-leaf-600" /> : <ArrowDown className="h-3.5 w-3.5 text-amber-600" />)}</div>
                          <div className="mt-1 font-display text-2xl font-bold tabular-nums text-forest">{fmtMetric(t, l.values[t])}<span className="ml-1 text-sm font-medium text-slate-500">{METRICS[t].unit}</span></div>
                          <Sparkline data={hist[k]} color={layerColor(l.id)} />
                        </div>
                      );
                    })}
                  </div>
                </section>
              ))}
            </div>
          </>
        )}
      </Async>
    </>
  );
}
