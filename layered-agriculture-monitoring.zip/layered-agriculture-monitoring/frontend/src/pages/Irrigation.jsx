import { useState } from 'react';
import { Droplets, FlaskConical, Play, Square, Timer } from 'lucide-react';
import { useApi } from '../hooks/useApi';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { Async, KpiCard, PageHeader, Section, TableWrap } from '../components/ui';
import TrendChart from '../charts/TrendChart';
import { dateTime, layerColor, num, shortLayer, timeAgo, zoneName } from '../utils/format';

export default function Irrigation() {
  const { isAdmin } = useAuth();
  const state = useApi('/irrigation', { interval: 5000 });
  const [busy, setBusy] = useState(null);
  const [msg, setMsg] = useState(null);

  const act = async (kind, layerId) => {
    setBusy(layerId); setMsg(null);
    try { await api.post(`/irrigation/${kind}`, { layer_id: layerId }); setMsg({ ok: true, text: kind === 'start' ? 'Simulated irrigation started.' : 'Simulated irrigation stopped.' }); await state.refresh(); }
    catch (e) { setMsg({ ok: false, text: e.message }); } finally { setBusy(null); }
  };

  return (
    <>
      <PageHeader title="Irrigation" subtitle="Water use per layer and simulated irrigation control." />
      <p className="mb-5 flex items-center gap-2 rounded-xl bg-amber-50 px-4 py-2.5 text-sm font-medium text-amber-700"><FlaskConical className="h-4 w-4 shrink-0" /> Simulated irrigation control — no real valves are connected. Starting a layer raises its simulated soil moisture and drains its tank.</p>
      {msg && <p role="status" className={`mb-4 rounded-xl px-4 py-2.5 text-sm ${msg.ok ? 'bg-leaf-50 text-leaf-800' : 'bg-rose-50 text-rose-700'}`}>{msg.text}</p>}

      <Async state={state}>
        {(d) => (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
              <KpiCard icon={Droplets} label="Water used today" value={d.totals.today} unit="L" decimals={0} change={null} note="" accent="bg-sky-50 text-sky-700" />
              <KpiCard icon={Droplets} label="This week" value={d.totals.week} unit="L" decimals={0} change={null} note="" accent="bg-sky-50 text-sky-700" />
              <KpiCard icon={Droplets} label="This month" value={d.totals.month} unit="L" decimals={0} change={null} note="" accent="bg-sky-50 text-sky-700" />
              <KpiCard icon={Timer} label="Irrigation time today" value={d.totals.durationToday} unit="min" decimals={0} change={null} note="" />
            </div>

            <Section title="Layer control" subtitle={`${d.totals.activeZones} of ${d.layers.length} layers irrigating now`}>
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                {d.layers.map((l) => {
                  const running = l.status === 'running';
                  return (
                    <div key={l.layerId} className="rounded-2xl border border-slate-100 p-4">
                      <div className="flex items-center justify-between"><div className="flex items-center gap-2 font-semibold text-forest"><span className="h-2.5 w-2.5 rounded-full" style={{ background: layerColor(l.layerId) }} />{shortLayer(l.name)}</div>
                        <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${running ? 'bg-sky-100 text-sky-700' : 'bg-slate-100 text-slate-600'}`}>{running ? 'Running' : 'Idle'}</span></div>
                      <div className="text-xs text-slate-500">{zoneName(l.name)} · {l.crop}</div>
                      <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
                        <div><dt className="text-xs text-slate-500">Soil moisture</dt><dd className="font-bold">{num(l.soilMoisture)}%</dd></div>
                        <div><dt className="text-xs text-slate-500">Tank level</dt><dd className="font-bold">{num(l.tankLevel)}%</dd></div>
                        <div><dt className="text-xs text-slate-500">Flow rate</dt><dd className="font-bold">{l.flowLitresPerMin} L/min</dd></div>
                        <div><dt className="text-xs text-slate-500">Used (30 d)</dt><dd className="font-bold">{num(l.month, 0)} L</dd></div>
                      </dl>
                      <div className="mt-2 text-xs text-slate-500">{l.lastRun ? `Last run ${timeAgo(l.lastRun.timestamp)} · ${l.lastRun.duration} min` : 'No runs yet'}</div>
                      <div className="mt-3 flex gap-2">
                        <button className="btn-primary flex-1 !py-2" disabled={!isAdmin || running || busy === l.layerId} onClick={() => act('start', l.layerId)} title={isAdmin ? '' : 'Admins only'}><Play className="h-4 w-4" /> Start Irrigation</button>
                        <button className="btn-ghost !py-2" disabled={!isAdmin || !running || busy === l.layerId} onClick={() => act('stop', l.layerId)} aria-label={`Stop irrigation for ${shortLayer(l.name)}`}><Square className="h-4 w-4" /> Stop</button>
                      </div>
                    </div>
                  );
                })}
              </div>
              {!isAdmin && <p className="mt-3 text-xs text-slate-500">Viewer accounts can monitor irrigation but only admins can start or stop it.</p>}
            </Section>

            <div className="grid gap-6 lg:grid-cols-3">
              <Section title="Daily water consumption — last 30 days" subtitle="Litres per layer" className="lg:col-span-2">
                <TrendChart type="bar" stacked data={d.chart} series={d.layers.map((l) => ({ key: `L${l.layerId}`, name: shortLayer(l.name), color: layerColor(l.layerId) }))} granularity="day" unit="L" height={280} />
              </Section>
              <Section title="Layer-wise consumption" subtitle="Last 30 days">
                <ul className="space-y-4">
                  {d.layers.map((l) => { const max = Math.max(...d.layers.map((x) => x.month), 1); return (
                    <li key={l.layerId}><div className="mb-1 flex justify-between text-sm"><span className="font-semibold text-forest">{shortLayer(l.name)}</span><span>{num(l.month, 0)} L</span></div>
                      <div className="h-2.5 rounded-full bg-mist"><div className="h-2.5 rounded-full" style={{ width: `${(l.month / max) * 100}%`, background: layerColor(l.layerId) }} /></div>
                      <div className="mt-1 text-xs text-slate-500">{l.sessionsMonth} sessions · {num(l.week, 0)} L this week</div></li>); })}
                </ul>
              </Section>
            </div>

            <Section title="Recent irrigation events">
              <TableWrap><thead><tr><th className="th">Layer</th><th className="th">Started</th><th className="th">Duration</th><th className="th">Water used</th><th className="th">Status</th></tr></thead>
                <tbody className="divide-y divide-slate-100">{d.recent.map((r) => <tr key={r.id}><td className="td font-semibold text-forest">{shortLayer(r.layer)}</td><td className="td">{dateTime(r.timestamp)}</td><td className="td">{r.duration} min</td><td className="td">{num(r.water_used, 0)} L</td><td className="td capitalize">{r.status}</td></tr>)}</tbody></TableWrap>
            </Section>
          </div>
        )}
      </Async>
    </>
  );
}
