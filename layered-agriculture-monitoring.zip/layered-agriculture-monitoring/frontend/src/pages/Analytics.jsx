import { useState } from 'react';
import { Download, Lightbulb, ShieldAlert, Sprout, TriangleAlert } from 'lucide-react';
import { useApi } from '../hooks/useApi';
import { Async, PageHeader, RangeFilter, Section, SeverityBadge, Tabs } from '../components/ui';
import TrendChart, { CompareBars } from '../charts/TrendChart';
import { downloadCsv } from '../services/api';
import { FARM_COLOR, METRICS, layerColor, num, shortLayer } from '../utils/format';

const TREND_TABS = [['temperature', 'Temperature'], ['humidity', 'Humidity'], ['soil_moisture', 'Soil moisture'], ['water_usage', 'Water consumption'], ['crop_health', 'Crop health']];
const KIND_ICON = { insight: Lightbulb, recommendation: Sprout, warning: TriangleAlert };

function Stat({ label, value, unit, sub }) {
  return (
    <div className="rounded-xl border border-slate-100 bg-white p-4">
      <div className="text-xs font-medium text-slate-500">{label}</div>
      <div className="mt-1 font-display text-2xl font-bold text-forest">{value}<span className="ml-1 text-sm font-medium text-slate-500">{unit}</span></div>
      {sub && <div className="text-xs text-slate-400">{sub}</div>}
    </div>
  );
}

// colour a correlation cell: green = positive, amber/red = negative, strength sets the opacity
const cellStyle = (r) => (r == null ? { background: '#f1f5f2' } : { background: r >= 0 ? `rgba(52,151,92,${Math.abs(r) * 0.75})` : `rgba(214,69,69,${Math.abs(r) * 0.7})`, color: Math.abs(r) > 0.55 ? '#fff' : '#123a25' });

export default function Analytics() {
  const [range, setRange] = useState('7d');
  const [metric, setMetric] = useState('temperature');
  const [chart, setChart] = useState('line');
  const [hidden, setHidden] = useState([]);
  const [busy, setBusy] = useState(false);
  const [dlError, setDlError] = useState('');
  const state = useApi(`/analytics?range=${range}`);

  const exportCsv = async () => { setBusy(true); setDlError(''); try { await downloadCsv({ range }); } catch (e) { setDlError(e.message); } finally { setBusy(false); } };

  return (
    <>
      <PageHeader title="Data Analytics" subtitle="Descriptive, trend, comparative and correlation analysis of your sensor data.">
        <RangeFilter value={range} onChange={setRange} />
        <button className="btn-dark" onClick={exportCsv} disabled={busy}><Download className="h-4 w-4" /> Export Report (CSV)</button>
      </PageHeader>
      {dlError && <p className="mb-4 rounded-xl bg-rose-50 px-3 py-2 text-sm text-rose-700" role="alert">{dlError}</p>}

      <Async state={state}>
        {({ summary: s, trends: t, comparison: c, correlation: corr, insights }) => {
          const m = METRICS[metric];
          const layerSeries = t.layers.filter((l) => !hidden.includes(l.key)).map((l) => ({ key: l.key, name: shortLayer(l.name), color: layerColor(l.id) }));
          const series = [...layerSeries, ...(hidden.includes('farm') ? [] : [{ key: 'farm', name: metric === 'water_usage' ? 'Farm total' : 'Farm average', color: FARM_COLOR, dashed: true }])];
          const bars = c.layers.map((l) => ({ ...l, short: shortLayer(l.name), color: layerColor(l.layerId) }));
          const toggle = (k) => setHidden((h) => (h.includes(k) ? h.filter((x) => x !== k) : [...h, k]));
          return (
            <div className="space-y-6">
              <Section title="1 · Descriptive analytics" subtitle={`Summary statistics for ${range === 'today' ? 'the last 24 hours' : range === '7d' ? 'the last 7 days' : 'the last 30 days'} (${num(s.readingCount, 0)} readings)`}>
                <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                  <Stat label="Average temperature" value={num(s.averageTemperature)} unit="°C" />
                  <Stat label="Maximum temperature" value={num(s.maxTemperature)} unit="°C" />
                  <Stat label="Minimum temperature" value={num(s.minTemperature)} unit="°C" />
                  <Stat label="Average humidity" value={num(s.averageHumidity)} unit="%" />
                  <Stat label="Average soil moisture" value={num(s.averageSoilMoisture)} unit="%" />
                  <Stat label="Total water consumption" value={num(s.totalWaterUsage, 0)} unit="L" />
                  <Stat label="Average crop health" value={num(s.averageCropHealth)} unit="%" />
                  <Stat label="Alerts in period" value={num(s.alertCount, 0)} unit="" sub={`${s.activeAlerts} still active`} />
                </div>
              </Section>

              <Section title="2 · Trend analysis" subtitle="How each measurement changed over time">
                <Tabs tabs={TREND_TABS} value={metric} onChange={setMetric} />
                <div className="my-4 flex flex-wrap gap-2" role="group" aria-label="Show or hide series">
                  {[...t.layers.map((l) => ({ key: l.key, name: shortLayer(l.name), color: layerColor(l.id) })), { key: 'farm', name: 'Farm', color: FARM_COLOR }].map((x) => (
                    <button key={x.key} onClick={() => toggle(x.key)} aria-pressed={!hidden.includes(x.key)} className={`flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-semibold ${hidden.includes(x.key) ? 'border-slate-200 text-slate-400' : 'border-slate-300 text-slate-700'}`}>
                      <span className="h-2.5 w-2.5 rounded-full" style={{ background: hidden.includes(x.key) ? '#cbd5e1' : x.color }} />{x.name}
                    </button>
                  ))}
                </div>
                <TrendChart data={t.series[metric]} series={series} granularity={t.granularity} unit={m.unit} type={metric === 'water_usage' ? 'bar' : 'line'} height={320} />
              </Section>

              <Section title="3 · Comparative analytics" subtitle="Layer 1 vs Layer 2 vs Layer 3 vs Layer 4"
                action={<div className="inline-flex rounded-xl border border-slate-200 p-1">{[['line', 'Line'], ['area', 'Area'], ['bar', 'Bar']].map(([k, l]) => <button key={k} onClick={() => setChart(k)} aria-pressed={chart === k} className={`rounded-lg px-3 py-1 text-sm font-semibold ${chart === k ? 'bg-forest text-white' : 'text-slate-600'}`}>{l}</button>)}</div>}>
                <Tabs tabs={TREND_TABS} value={metric} onChange={setMetric} />
                <div className="mt-4">
                  {chart === 'bar'
                    ? <CompareBars rows={bars} metric={metric} unit={m.unit} />
                    : <TrendChart data={t.series[metric]} series={t.layers.map((l) => ({ key: l.key, name: shortLayer(l.name), color: layerColor(l.id) }))} granularity={t.granularity} unit={m.unit} type={chart} height={300} />}
                </div>
                <div className="mt-4 overflow-x-auto rounded-xl border border-slate-100">
                  <table className="min-w-full divide-y divide-slate-100 text-sm">
                    <thead><tr><th className="th">Layer</th><th className="th">Temp °C</th><th className="th">Humidity %</th><th className="th">Soil moisture %</th><th className="th">Water L</th><th className="th">Crop health %</th><th className="th">Alerts</th></tr></thead>
                    <tbody className="divide-y divide-slate-100">{bars.map((r) => <tr key={r.key}><td className="td font-semibold text-forest"><span className="mr-2 inline-block h-2.5 w-2.5 rounded-full" style={{ background: r.color }} />{r.short} · {r.crop}</td><td className="td">{num(r.temperature)}</td><td className="td">{num(r.humidity)}</td><td className="td">{num(r.soil_moisture)}</td><td className="td">{num(r.water_usage, 0)}</td><td className="td">{num(r.crop_health)}</td><td className="td">{r.alerts}</td></tr>)}</tbody>
                  </table>
                </div>
              </Section>

              <Section title="4 · Correlation analysis" subtitle={corr.basis}>
                <div className="grid gap-6 lg:grid-cols-2">
                  <div className="space-y-3">
                    {corr.highlights.map((h) => (
                      <div key={h.x + h.y} className="rounded-xl border border-slate-100 p-4">
                        <div className="flex items-baseline justify-between gap-2"><span className="text-sm font-semibold text-forest">{METRICS[h.x].label} vs {METRICS[h.y].label}</span><span className="font-display text-xl font-bold text-forest">{h.r == null ? '—' : `${h.r > 0 ? '+' : ''}${h.r.toFixed(2)}`}</span></div>
                        <p className="mt-1 text-sm text-slate-600">{h.explanation}</p>
                      </div>
                    ))}
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[420px] border-separate border-spacing-1 text-center text-xs">
                      <thead><tr><th />{corr.labels.map((l) => <th key={l} className="px-1 pb-1 font-semibold capitalize text-slate-500">{l}</th>)}</tr></thead>
                      <tbody>{corr.matrix.map((row, i) => (
                        <tr key={i}><th className="pr-2 text-right font-semibold capitalize text-slate-500">{corr.labels[i]}</th>{row.map((r, j) => <td key={j} className="rounded-lg py-3 font-semibold tabular-nums" style={cellStyle(r)} title={`${corr.labels[i]} vs ${corr.labels[j]}`}>{r == null ? '—' : r.toFixed(2)}</td>)}</tr>))}</tbody>
                    </table>
                  </div>
                </div>
                <p className="mt-4 flex gap-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-700"><ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />{corr.note}</p>
              </Section>

              <Section title="5 · Agricultural insights" subtitle="Calculated from real readings — not hardcoded text">
                <ul className="grid gap-3 md:grid-cols-2">
                  {insights.map((i) => { const Icon = KIND_ICON[i.kind] || Lightbulb; return (
                    <li key={i.id} className="flex gap-3 rounded-xl bg-mist p-4">
                      <Icon className={`mt-0.5 h-5 w-5 shrink-0 ${i.severity === 'warning' || i.severity === 'critical' ? 'text-amber-600' : 'text-leaf-600'}`} />
                      <div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><span className="text-sm font-semibold text-forest">{i.title}</span><SeverityBadge severity={i.severity} /></div><p className="mt-1 text-sm text-slate-600">{i.text}</p></div>
                    </li>); })}
                </ul>
              </Section>
            </div>
          );
        }}
      </Async>
    </>
  );
}
