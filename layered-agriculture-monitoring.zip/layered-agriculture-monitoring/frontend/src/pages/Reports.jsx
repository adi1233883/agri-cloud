import { useEffect, useState } from 'react';
import { Download, Printer } from 'lucide-react';
import { useApi } from '../hooks/useApi';
import { api, downloadCsv } from '../services/api';
import { PageHeader, RangeFilter, Section, Spinner, TableWrap, ErrorState } from '../components/ui';
import { dateTime, num, shortLayer } from '../utils/format';

const METRIC_OPTS = [['temperature', 'Temperature'], ['humidity', 'Humidity'], ['soil_moisture', 'Soil moisture'], ['soil_ph', 'Soil pH'], ['water_usage', 'Water usage'], ['crop_health', 'Crop health'], ['alerts', 'Alerts']];

export default function Reports() {
  const layers = useApi('/layers');
  const [layer, setLayer] = useState('all');
  const [range, setRange] = useState('7d');
  const [metrics, setMetrics] = useState(METRIC_OPTS.map(([k]) => k));
  const [report, setReport] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [dl, setDl] = useState(false);

  const generate = async () => {
    if (!metrics.length) return setError('Select at least one metric.');
    setLoading(true); setError('');
    try { setReport(await api.get(`/reports?layer_id=${layer}&range=${range}&metrics=${metrics.join(',')}`)); } catch (e) { setError(e.message); setReport(null); } finally { setLoading(false); }
  };
  useEffect(() => { if (layers.data) generate(); }, [layers.data]); // eslint-disable-line react-hooks/exhaustive-deps

  const toggle = (k) => setMetrics((m) => (m.includes(k) ? m.filter((x) => x !== k) : [...m, k]));

  return (
    <>
      <PageHeader title="Reports" subtitle="Pick a layer, period and metrics to generate a summary with recommendations." />
      <Section className="no-print mb-6">
        <div className="grid gap-4 md:grid-cols-3">
          <div><label className="label" htmlFor="rl">Layer</label>
            <select id="rl" className="input" value={layer} onChange={(e) => setLayer(e.target.value)}>
              <option value="all">All layers</option>{layers.data?.layers.map((l) => <option key={l.id} value={l.id}>{l.layer_name}</option>)}</select></div>
          <div><span className="label">Date range</span><RangeFilter value={range} onChange={setRange} /></div>
          <div className="flex items-end"><button className="btn-primary w-full md:w-auto" onClick={generate} disabled={loading}>Generate report</button></div>
        </div>
        <fieldset className="mt-4"><legend className="label">Metrics</legend>
          <div className="flex flex-wrap gap-2">{METRIC_OPTS.map(([k, l]) => (
            <label key={k} className={`flex cursor-pointer items-center gap-2 rounded-full border px-3 py-1.5 text-sm font-semibold ${metrics.includes(k) ? 'border-leaf-500 bg-leaf-50 text-leaf-800' : 'border-slate-200 text-slate-500'}`}>
              <input type="checkbox" className="h-4 w-4 accent-leaf-600" checked={metrics.includes(k)} onChange={() => toggle(k)} />{l}</label>))}</div></fieldset>
      </Section>

      {error && <ErrorState message={error} onRetry={generate} />}
      {loading && !report && <Spinner label="Generating report…" />}
      {report && (
        <article className="card p-6">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div><h2 className="text-2xl font-bold">{report.title}</h2><p className="text-sm text-slate-500">Generated {dateTime(report.generatedAt)}</p></div>
            <div className="no-print flex gap-2">
              <button className="btn-ghost" onClick={() => window.print()}><Printer className="h-4 w-4" /> Print</button>
              <button className="btn-dark" disabled={dl} onClick={async () => { setDl(true); try { await downloadCsv({ range, layerId: layer }); } catch (e) { setError(e.message); } finally { setDl(false); } }}><Download className="h-4 w-4" /> Export Report</button>
            </div>
          </div>
          <dl className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
            {report.stats.map((s) => <div key={s.key} className="rounded-xl bg-mist p-4"><dt className="text-xs font-medium text-slate-500">{s.label}</dt><dd className="mt-1 font-display text-2xl font-bold text-forest">{s.value == null ? '—' : num(s.value, s.key === 'water_usage' || s.key === 'alerts' ? 0 : s.key === 'soil_ph' ? 2 : 1)}<span className="ml-1 text-sm font-medium text-slate-500">{s.unit}</span></dd></div>)}
          </dl>
          <div className="mt-5 rounded-xl border border-leaf-200 bg-leaf-50 p-4"><h3 className="text-sm font-bold uppercase tracking-wide text-leaf-800">Recommendation</h3><ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-leaf-900">{report.recommendations.map((r) => <li key={r}>{r}</li>)}</ul></div>
          {report.table.length > 0 && (
            <div className="mt-6"><h3 className="mb-2 text-lg font-bold">Data preview</h3>
              <TableWrap><thead><tr><th className="th">Time</th><th className="th">Layer</th><th className="th">Temp °C</th><th className="th">Humidity %</th><th className="th">Moisture %</th><th className="th">pH</th><th className="th">Water L</th><th className="th">Health %</th></tr></thead>
                <tbody className="divide-y divide-slate-100">{report.table.map((r) => <tr key={r.bucket + r.layer_id}><td className="td">{dateTime(r.bucket)}</td><td className="td">{shortLayer(r.layer)}</td><td className="td">{num(r.temperature)}</td><td className="td">{num(r.humidity)}</td><td className="td">{num(r.soil_moisture)}</td><td className="td">{num(r.soil_ph, 2)}</td><td className="td">{num(r.water_usage, 0)}</td><td className="td">{num(r.crop_health)}</td></tr>)}</tbody></TableWrap>
              <p className="mt-2 text-xs text-slate-500">Showing the most recent rows. The CSV export contains the full period.</p></div>
          )}
        </article>
      )}
    </>
  );
}
