import { Link } from 'react-router-dom';
import { Plus } from 'lucide-react';
import { useApi } from '../hooks/useApi';
import { useAuth } from '../context/AuthContext';
import { Async, PageHeader } from '../components/ui';
import LayerCard from '../components/LayerCard';

export default function Layers() {
  const state = useApi('/layers', { interval: 15000 });
  const { isAdmin } = useAuth();
  return (
    <>
      <PageHeader title="Farm Layers" subtitle="Each layer is a zone with its own crop, sensors and irrigation.">
        {isAdmin && <Link to="/settings#admin" className="btn-primary"><Plus className="h-4 w-4" /> Add layer or sensor</Link>}
      </PageHeader>
      <Async state={state} empty={Object.assign((d) => d.layers.length === 0, { title: 'No layers yet', text: 'An admin can add the first layer in Settings.' })}>
        {(d) => <div className="grid gap-5 md:grid-cols-2 2xl:grid-cols-4">{d.layers.map((l) => <LayerCard key={l.id} layer={l} />)}</div>}
      </Async>
    </>
  );
}
