import { Link } from 'react-router-dom';
import { Bell, Droplets, Lightbulb, Sprout, Sun, Thermometer, Waves, ArrowRight } from 'lucide-react';
import { useApi } from '../hooks/useApi';
import { Async, ConditionBadge, KpiCard, LiveBadge, PageHeader, Section, SeverityBadge, EmptyState } from '../components/ui';
import TrendChart from '../charts/TrendChart';
import { FARM_COLOR, layerColor, num, shortLayer, timeAgo, zoneName } from '../utils/format';

export default function Dashboard() {
  const state = useApi('/dashboard/stats', { interval: 15000 });
  return (
    <Async state={state}>
      {(d) => {
        const k = d.kpis;
        const series = [...d.trend.layers.map((l) => ({ key: l.key, name: shortLayer(l.name), color: layerColor(l.id) })), { key: 'farm', name: 'Farm average', color: FARM_COLOR, dashed: true }];
        return (
          <>
            <PageHeader title={d.farm.farm_name} subtitle={`${d.farm.location} · ${num(d.farm.total_area, 0)} ha across ${d.layers.length} layers`}>
              <LiveBadge updatedAt={d.updatedAt} />
            </PageHeader>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
              <KpiCard icon={Thermometer} label={k.temperature.label} value={k.temperature.value} unit={k.temperature.unit} change={k.temperature.change} tone="neutral" spark={k.temperature.spark} accent="bg-amber-100 text-amber-700" />
              <KpiCard icon={Waves} label={k.soilMoisture.label} value={k.soilMoisture.value} unit="%" change={k.soilMoisture.change} tone="upGood" spark={k.soilMoisture.spark} accent="bg-sky-50 text-sky-700" />
              <KpiCard icon={Sprout} label={k.cropHealth.label} value={k.cropHealth.value} unit="%" change={k.cropHealth.change} tone="upGood" spark={k.cropHealth.spark} />
              <KpiCard icon={Droplets} label={k.water.label} value={k.water.value} unit="L" change={k.water.change} tone="neutral" spark={k.water.spark} decimals={0} note="vs previous 24 h" accent="bg-sky-50 text-sky-700" />
              <KpiCard icon={Sun} label={k.light.label} value={k.light.value} unit="lux" change={k.light.change} tone="neutral" spark={k.light.spark} decimals={0} accent="bg-amber-100 text-amber-700" />
              <KpiCard icon={Bell} label={k.alerts.label} value={k.alerts.value} unit="" change={k.alerts.change} tone="upBad" decimals={0} note="alerts vs previous 24 h" accent="bg-rose-100 text-rose-600" />
            </div>

            <div className="mt-6 grid gap-6 xl:grid-cols-3">
              <Section title="Layers at a glance" className="xl:col-span-2" action={<Link to="/layers" className="text-sm font-semibold text-leaf-700 hover:underline">All layers</Link>}>
                <div className="grid gap-3 sm:grid-cols-2">
                  {d.layers.map((l) => (
                    <Link key={l.id} to={`/layers/${l.id}`} className="group rounded-xl border border-slate-100 p-4 transition hover:border-leaf-300 hover:bg-leaf-50/40">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2"><span className="h-3 w-3 rounded-full" style={{ background: layerColor(l.id) }} /><span className="font-semibold text-forest">{shortLayer(l.name)} · {zoneName(l.name).replace(' Zone', '')}</span></div>
                        <ConditionBadge condition={l.condition} />
                      </div>
                      <div className="mt-3 grid grid-cols-3 gap-2 text-sm">
                        <div><div className="text-xs text-slate-500">Temp</div><b>{num(l.values.temperature)}°C</b></div>
                        <div><div className="text-xs text-slate-500">Moisture</div><b>{num(l.values.soil_moisture)}%</b></div>
                        <div><div className="text-xs text-slate-500">pH</div><b>{num(l.values.soil_ph, 2)}</b></div>
                      </div>
                      {l.irrigating && <div className="mt-2 text-xs font-semibold text-sky-700">💧 Irrigating now</div>}
                    </Link>
                  ))}
                </div>
              </Section>

              <Section title="Active alerts" action={<Link to="/alerts" className="text-sm font-semibold text-leaf-700 hover:underline">View all</Link>}>
                {d.alerts.length === 0 ? <EmptyState title="All quiet" text="No active alerts right now." /> : (
                  <ul className="space-y-3">
                    {d.alerts.map((a) => (
                      <li key={a.id} className="rounded-xl border border-slate-100 p-3">
                        <div className="flex items-center justify-between gap-2"><SeverityBadge severity={a.severity} /><span className="text-xs text-slate-400">{timeAgo(a.timestamp)}</span></div>
                        <p className="mt-2 text-sm text-slate-700">{a.message}</p>
                        <p className="mt-0.5 text-xs text-slate-500">{shortLayer(a.layer)}</p>
                      </li>
                    ))}
                  </ul>
                )}
              </Section>
            </div>

            <div className="mt-6 grid gap-6 lg:grid-cols-2">
              <Section title="Temperature — last 24 hours" subtitle="Hourly average per layer"><TrendChart data={d.trend.temperature} series={series} granularity="hour" unit="°C" height={260} type="line" /></Section>
              <Section title="Soil moisture — last 24 hours" subtitle="Hourly average per layer"><TrendChart data={d.trend.soil_moisture} series={series} granularity="hour" unit="%" height={260} type="line" /></Section>
            </div>

            <Section title="Agricultural insights" subtitle="Generated automatically from the latest readings" className="mt-6"
              action={<Link to="/analytics" className="inline-flex items-center gap-1 text-sm font-semibold text-leaf-700 hover:underline">Full analytics <ArrowRight className="h-4 w-4" /></Link>}>
              <ul className="grid gap-3 md:grid-cols-2">
                {d.insights.map((i) => (
                  <li key={i.id} className="flex gap-3 rounded-xl bg-mist p-4">
                    <Lightbulb className={`mt-0.5 h-5 w-5 shrink-0 ${i.severity === 'warning' || i.severity === 'critical' ? 'text-amber-600' : 'text-leaf-600'}`} />
                    <div><div className="text-sm font-semibold text-forest">{i.title}</div><p className="text-sm text-slate-600">{i.text}</p></div>
                  </li>
                ))}
              </ul>
            </Section>
          </>
        );
      }}
    </Async>
  );
}
