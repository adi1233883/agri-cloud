import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { Logo } from '../components/Layout';
import { LAYER_COLORS } from '../utils/format';

const FLOW = ['Sensors', 'Cloud API', 'Cloud database', 'Analytics', 'Dashboard', 'Alerts'];

export default function Login() {
  const { login, signup, cloud } = useAuth();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);
  const [demo, setDemo] = useState([]);

  useEffect(() => { api.get('/auth/demo-credentials').then(setDemo).catch(() => {}); }, []);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError(''); setInfo('');
    if (!/^\S+@\S+\.\S+$/.test(form.email)) return setError('Enter a valid email address.');
    if (form.password.length < 6) return setError('Password must be at least 6 characters.');
    if (mode === 'signup' && !form.name.trim()) return setError('Enter your name.');
    setBusy(true);
    try {
      if (mode === 'login') await login(form.email, form.password);
      else {
        const r = await signup(form.name.trim(), form.email, form.password);
        if (r.needsConfirmation) { setInfo('Account created. Check your email to confirm it, then log in.'); setMode('login'); }
      }
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden flex-col justify-between overflow-hidden bg-forest p-10 text-white lg:flex">
        <Logo light />
        <div>
          <div className="mb-8 space-y-3" aria-hidden="true">
            {LAYER_COLORS.slice(0, 4).map((c, i) => <div key={c} className="h-9 rounded-full opacity-90" style={{ background: c, width: `${92 - i * 14}%`, marginLeft: `${i * 4}%` }} />)}
          </div>
          <h1 className="max-w-md font-display text-4xl font-bold leading-tight !text-white">Every layer of your farm, in one live view.</h1>
          <p className="mt-4 max-w-md text-leaf-200">Cloud-connected sensors, analytics and alerts for vegetable, fruit, grain and greenhouse zones.</p>
        </div>
        <ol className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-semibold text-leaf-300">
          {FLOW.map((f, i) => <li key={f} className="flex items-center gap-2">{f}{i < FLOW.length - 1 && <span aria-hidden="true">→</span>}</li>)}
        </ol>
      </div>

      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="mb-8 lg:hidden"><Logo /></div>
          <h2 className="text-2xl font-bold">{mode === 'login' ? 'Welcome back' : 'Create your account'}</h2>
          <p className="mb-6 mt-1 text-sm text-slate-500">{mode === 'login' ? 'Log in to monitor your farm.' : 'New accounts start as Viewers.'}</p>

          <form onSubmit={submit} className="space-y-4" noValidate>
            {mode === 'signup' && <div><label className="label" htmlFor="name">Name</label><input id="name" className="input" value={form.name} onChange={set('name')} autoComplete="name" /></div>}
            <div><label className="label" htmlFor="email">Email</label><input id="email" type="email" className="input" value={form.email} onChange={set('email')} autoComplete="email" /></div>
            <div><label className="label" htmlFor="pw">Password</label><input id="pw" type="password" className="input" value={form.password} onChange={set('password')} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} /></div>
            {error && <p className="rounded-xl bg-rose-50 px-3 py-2 text-sm text-rose-700" role="alert">{error}</p>}
            {info && <p className="rounded-xl bg-leaf-50 px-3 py-2 text-sm text-leaf-800">{info}</p>}
            <button className="btn-primary w-full" disabled={busy}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}{mode === 'login' ? 'Log in' : 'Sign up'}</button>
          </form>

          {cloud && (
            <p className="mt-4 text-center text-sm text-slate-500">
              {mode === 'login' ? 'No account? ' : 'Already registered? '}
              <button className="font-semibold text-leaf-700 hover:underline" onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); }}>{mode === 'login' ? 'Sign up' : 'Log in'}</button>
            </p>
          )}

          {demo.length > 0 && (
            <div className="mt-8 rounded-2xl border border-dashed border-leaf-300 bg-leaf-50/60 p-4">
              <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-leaf-700">Demo accounts — tap to fill</div>
              <div className="space-y-2">
                {demo.map((d) => (
                  <button key={d.email} type="button" onClick={() => { setMode('login'); setForm({ name: '', email: d.email, password: d.password }); }} className="flex w-full items-center justify-between rounded-xl bg-white px-3 py-2 text-left text-sm hover:ring-2 hover:ring-leaf-200">
                    <span className="font-semibold text-forest">{d.email}</span><span className="rounded-full bg-leaf-100 px-2 py-0.5 text-xs font-semibold capitalize text-leaf-800">{d.role}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
