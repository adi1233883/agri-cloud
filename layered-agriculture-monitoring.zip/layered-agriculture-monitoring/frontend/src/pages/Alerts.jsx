import { useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { useApi } from '../hooks/useApi';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { Async, EmptyState, PageHeader, SeverityBadge, TableWrap, Tabs } from '../components/ui';
import { dateTime, shortLayer, timeAgo } from '../utils/format';

export default function Alerts() {
  const { isAdmin } = useAuth();
  const [status, setStatus] = useState('active');
  const [severity, setSeverity] = useState('');
  const qs = [status && `status=${status}`, severity && `severity=${severity}`].filter(Boolean).join('&');
  const state = useApi(`/alerts${qs ? `?${qs}` : ''}`, { interval: 15000 });
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState('');

  const resolve = async (id) => {
    setBusy(id); setError('');
    try { await api.post(`/alerts/${id}/resolve`); await state.refresh(); } catch (e) { setError(e.message); } finally { setBusy(null); }
  };

  return (
    <>
      <PageHeader title="Alerts" subtitle="Raised automatically when a sensor crosses a threshold. Alerts also clear themselves when values recover." />
      <div className="mb-4 flex flex-wrap items-center gap-4">
        <Tabs tabs={[['active', 'Active'], ['resolved', 'Resolved'], ['', 'All']]} value={status} onChange={setStatus} />
        <Tabs tabs={[['', 'Any severity'], ['critical', 'Critical'], ['warning', 'Warning'], ['info', 'Informational']]} value={severity} onChange={setSeverity} />
      </div>
      {error && <p className="mb-4 rounded-xl bg-rose-50 px-3 py-2 text-sm text-rose-700" role="alert">{error}</p>}
      <Async state={state}>
        {(rows) => rows.length === 0 ? (
          <div className="card"><EmptyState title={status === 'active' ? 'No active alerts' : 'No alerts found'} text="Everything is within the configured thresholds." /></div>
        ) : (
          <div className="card p-2">
            <TableWrap>
              <thead><tr><th className="th">Severity</th><th className="th">Layer</th><th className="th">Message</th><th className="th">Raised</th><th className="th">Status</th>{isAdmin && <th className="th" />}</tr></thead>
              <tbody className="divide-y divide-slate-100">
                {rows.map((a) => (
                  <tr key={a.id}>
                    <td className="td"><SeverityBadge severity={a.severity} /></td>
                    <td className="td font-semibold text-forest">{shortLayer(a.layer)}</td>
                    <td className="td !whitespace-normal min-w-[260px]">{a.message}</td>
                    <td className="td text-slate-500" title={dateTime(a.timestamp)}>{timeAgo(a.timestamp)}</td>
                    <td className="td capitalize">{a.status}</td>
                    {isAdmin && <td className="td">{a.status === 'active' && <button className="btn-ghost !py-1.5" disabled={busy === a.id} onClick={() => resolve(a.id)}><CheckCircle2 className="h-4 w-4" /> Mark resolved</button>}</td>}
                  </tr>
                ))}
              </tbody>
            </TableWrap>
          </div>
        )}
      </Async>
      {!isAdmin && <p className="mt-3 text-xs text-slate-500">Only admins can mark alerts as resolved.</p>}
    </>
  );
}
