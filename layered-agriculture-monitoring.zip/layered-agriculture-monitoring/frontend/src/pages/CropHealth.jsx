import { useApi } from '../hooks/useApi';
import { Async, HealthRing, PageHeader, Sparkline } from '../components/ui';
import { dateTime, layerColor, shortLayer, timeAgo } from '../utils/format';

const RISK = { Low: 'bg-leaf-100 text-leaf-800', Medium: 'bg-amber-100 text-amber-700', High: 'bg-rose-100 text-rose-700' };

export default function CropHealth() {
  const state = useApi('/crop-health', { interval: 30000 });
  return (
    <>
      <PageHeader title="Crop Health" subtitle="Health score blends soil moisture, temperature, pH and humidity against what each crop prefers." />
      <Async state={state} empty={Object.assign((d) => d.length === 0, { title: 'No crops yet', text: 'Crop health appears once a layer has readings.' })}>
        {(rows) => (
          <div className="grid gap-5 md:grid-cols-2">
            {rows.map((c) => (
              <article key={c.layerId} className="card fade-up p-5">
                <div className="flex items-center gap-5">
                  <HealthRing score={c.healthScore} size={104} />
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-semibold uppercase tracking-wide" style={{ color: layerColor(c.layerId) }}>{shortLayer(c.layer)}</div>
                    <h2 className="text-2xl font-bold">{c.crop}</h2>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${RISK[c.diseaseRisk] || 'bg-slate-100 text-slate-600'}`}>Disease risk: {c.diseaseRisk ?? '—'}</span>
                      <span className="rounded-full bg-mist px-2.5 py-1 text-xs font-semibold text-slate-600">Growth: {c.growth ?? '—'}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-4"><div className="mb-1 text-xs text-slate-500">Health score — last 30 days</div><Sparkline data={c.history.map((h) => h.score)} color={layerColor(c.layerId)} /></div>
                <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 border-t border-slate-100 pt-3 text-xs text-slate-500">
                  <div><dt className="inline">Preferred temp: </dt><dd className="inline font-semibold text-slate-700">{c.preferred.temperature.join('–')}°C</dd></div>
                  <div><dt className="inline">Soil moisture: </dt><dd className="inline font-semibold text-slate-700">{c.preferred.soil_moisture.join('–')}%</dd></div>
                  <div><dt className="inline">Soil pH: </dt><dd className="inline font-semibold text-slate-700">{c.preferred.soil_ph.join('–')}</dd></div>
                  <div><dt className="inline">Last inspection: </dt><dd className="inline font-semibold text-slate-700" title={dateTime(c.lastInspection)}>{timeAgo(c.lastInspection)}</dd></div>
                </dl>
              </article>
            ))}
          </div>
        )}
      </Async>
    </>
  );
}
