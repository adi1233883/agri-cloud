import { useState } from 'react';
import { useApi } from '../hooks/useApi';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { Async, PageHeader, Section, TableWrap } from '../components/ui';

const RULES = [
  ['Soil moisture', '< 30% (critical below 22%)', 'Low soil moisture detected', 'Warning / Critical'],
  ['Soil moisture', '30–35%', 'Approaching the dry threshold', 'Informational'],
  ['Temperature', '> 35°C (critical above 37.5°C)', 'High temperature warning', 'Warning / Critical'],
  ['Soil pH', '< 5.5 (critical below 5.0)', 'Soil pH below recommended range', 'Warning / Critical'],
  ['Water tank level', '< 20% (critical below 10%)', 'Low water tank level', 'Warning / Critical'],
  ['Humidity', '> 85%', 'Fungal disease watch', 'Informational'],
];
const TYPES = ['temperature', 'humidity', 'soil_moisture', 'soil_ph', 'light', 'water_level', 'co2', 'rainfall'];

function AdminForms() {
  const layers = useApi('/layers');
  const [layer, setLayer] = useState({ layer_name: '', crop_type: '', area: '' });
  const [sensor, setSensor] = useState({ layer_id: '', sensor_type: 'temperature', sensor_name: '' });
  const [msg, setMsg] = useState({});

  const submit = (key, path, body, reset) => async (e) => {
    e.preventDefault(); setMsg((m) => ({ ...m, [key]: null }));
    try { await api.post(path, body); setMsg((m) => ({ ...m, [key]: { ok: true, text: 'Saved.' } })); reset(); layers.refresh(); }
    catch (err) { setMsg((m) => ({ ...m, [key]: { ok: false, text: err.message } })); }
  };
  const Msg = ({ k }) => (msg[k] ? <p role="status" className={`text-sm ${msg[k].ok ? 'text-leaf-700' : 'text-rose-700'}`}>{msg[k].text}</p> : null);

  return (
    <Section title="Farm configuration" subtitle="Admin only" className="scroll-mt-24">
      <div id="admin" className="grid gap-8 lg:grid-cols-2">
        <form className="space-y-3" onSubmit={submit('layer', '/layers', { ...layer, area: Number(layer.area) }, () => setLayer({ layer_name: '', crop_type: '', area: '' }))}>
          <h3 className="font-bold">Add a layer</h3>
          <div><label className="label" htmlFor="ln">Layer name</label><input id="ln" required maxLength={80} className="input" value={layer.layer_name} onChange={(e) => setLayer({ ...layer, layer_name: e.target.value })} placeholder="Layer 5 — Herb Zone" /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label" htmlFor="lc">Crop</label><input id="lc" required className="input" value={layer.crop_type} onChange={(e) => setLayer({ ...layer, crop_type: e.target.value })} placeholder="Tomato" /></div>
            <div><label className="label" htmlFor="la">Area (ha)</label><input id="la" required type="number" min="0.1" step="0.1" className="input" value={layer.area} onChange={(e) => setLayer({ ...layer, area: e.target.value })} /></div>
          </div>
          <button className="btn-primary">Add layer</button><Msg k="layer" />
        </form>
        <form className="space-y-3" onSubmit={submit('sensor', '/sensors', { ...sensor, layer_id: Number(sensor.layer_id) }, () => setSensor({ ...sensor, sensor_name: '' }))}>
          <h3 className="font-bold">Add a sensor</h3>
          <div><label className="label" htmlFor="sl">Layer</label>
            <select id="sl" required className="input" value={sensor.layer_id} onChange={(e) => setSensor({ ...sensor, layer_id: e.target.value })}><option value="">Choose…</option>{layers.data?.layers.map((l) => <option key={l.id} value={l.id}>{l.layer_name}</option>)}</select></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label" htmlFor="st">Type</label><select id="st" className="input" value={sensor.sensor_type} onChange={(e) => setSensor({ ...sensor, sensor_type: e.target.value })}>{TYPES.map((t) => <option key={t} value={t}>{t.replace('_', ' ')}</option>)}</select></div>
            <div><label className="label" htmlFor="sn">Name (optional)</label><input id="sn" className="input" value={sensor.sensor_name} onChange={(e) => setSensor({ ...sensor, sensor_name: e.target.value })} /></div>
          </div>
          <button className="btn-primary">Add sensor</button><Msg k="sensor" />
        </form>
      </div>
    </Section>
  );
}

export default function Settings() {
  const { user, isAdmin, cloud } = useAuth();
  const mode = useApi('/auth/mode');
  return (
    <>
      <PageHeader title="Settings" subtitle="Your account, system status and alert thresholds." />
      <div className="space-y-6">
        <div className="grid gap-6 md:grid-cols-2">
          <Section title="Account">
            <dl className="space-y-2 text-sm"><div className="flex justify-between"><dt className="text-slate-500">Name</dt><dd className="font-semibold text-forest">{user.name}</dd></div><div className="flex justify-between"><dt className="text-slate-500">Email</dt><dd className="font-semibold text-forest">{user.email}</dd></div><div className="flex justify-between"><dt className="text-slate-500">Role</dt><dd className="font-semibold capitalize text-forest">{user.role}</dd></div></dl>
            <p className="mt-3 text-xs text-slate-500">Admins can add layers and sensors, resolve alerts and control simulated irrigation. Viewers can see the dashboard, analytics and alerts.</p>
          </Section>
          <Section title="System status">
            <Async state={mode}>{(m) => (
              <dl className="space-y-2 text-sm"><div className="flex justify-between"><dt className="text-slate-500">Database</dt><dd className="font-semibold text-forest">{m.database === 'supabase' ? 'Supabase (cloud PostgreSQL)' : 'In-memory demo database'}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Authentication</dt><dd className="font-semibold text-forest">{cloud ? 'Supabase Auth' : 'Demo login'}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Sensor data</dt><dd className="font-semibold text-forest">Simulated sensors</dd></div></dl>)}</Async>
          </Section>
        </div>
        <Section title="Alert thresholds" subtitle="Rules the backend checks against every new reading">
          <TableWrap><thead><tr><th className="th">Sensor</th><th className="th">Condition</th><th className="th">Message</th><th className="th">Severity</th></tr></thead>
            <tbody className="divide-y divide-slate-100">{RULES.map((r) => <tr key={r.join()}>{r.map((c) => <td key={c} className="td">{c}</td>)}</tr>)}</tbody></TableWrap>
        </Section>
        {isAdmin && <AdminForms />}
      </div>
    </>
  );
}
