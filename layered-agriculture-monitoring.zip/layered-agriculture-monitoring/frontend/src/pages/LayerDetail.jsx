import { Link, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useApi } from '../hooks/useApi';
import { Async, ConditionBadge, HealthRing, PageHeader, Section, SeverityBadge, TableWrap } from '../components/ui';
import TrendChart from '../charts/TrendChart';
import { METRICS, dateTime, fmtMetric, layerColor, num, shortLayer, zoneName } from '../utils/format';

export default function LayerDetail() {
  const { id } = useParams();
  const state = useApi(`/layers/${id}`, { interval: 15000 });
  return (
    <>
      <Link to="/layers" className="mb-4 inline-flex items-center gap-1.5 text-sm font-semibold text-leaf-700 hover:underline"><ArrowLeft className="h-4 w-4" /> All layers</Link>
      <Async state={state}>
        {(d) => {
          const l = d.layer, pref = d.preferred, color = layerColor(l.id);
          const s1 = [{ key: `L${l.id}`, name: shortLayer(l.layer_name), color }];
          return (
            <>
              <PageHeader title={zoneName(l.layer_name)} subtitle={`${shortLayer(l.layer_name)} · ${l.crop_type} · ${num(l.area, 1)} ha`}><ConditionBadge condition={l.condition} /></PageHeader>
              <div className="grid gap-6 lg:grid-cols-3">
                <Section title="Sensors" subtitle="Latest readings and the range preferred by this crop" className="lg:col-span-2">
                  <div className="grid gap-3 sm:grid-cols-2">
                    {d.sensors.map((s) => {
                      const r = pref[s.sensor_type];
                      const out = r && s.value != null && (s.value < r[0] || s.value > r[1]);
                      return (
                        <div key={s.id} className="rounded-xl border border-slate-100 p-3.5">
                          <div className="flex items-center justify-between text-xs text-slate-500"><span>{METRICS[s.sensor_type]?.label}</span><span className="capitalize">{s.status}</span></div>
                          <div className={`mt-1 font-display text-2xl font-bold ${out ? 'text-amber-600' : 'text-forest'}`}>{fmtMetric(s.sensor_type, s.value)}<span className="ml-1 text-sm font-medium text-slate-500">{s.unit}</span></div>
                          {r && <div className="text-xs text-slate-500">Preferred {r[0]}–{r[1]} {s.unit}{out && <b className="ml-1 text-amber-600">· outside range</b>}</div>}
                        </div>
                      );
                    })}
                  </div>
                </Section>
                <Section title="Crop health">
                  <div className="flex items-center gap-4">
                    <HealthRing score={l.health?.health_score} />
                    <div className="text-sm"><div className="font-semibold text-forest">{l.health?.growth_status ?? '—'}</div><div className="text-slate-500">Disease risk: <b>{l.health?.disease_risk ?? '—'}</b></div><div className="text-xs text-slate-400">Inspected {dateTime(l.health?.timestamp)}</div></div>
                  </div>
                </Section>
              </div>
              <div className="mt-6 grid gap-6 lg:grid-cols-2">
                <Section title="Temperature — 24 h"><TrendChart data={d.trend.temperature} series={s1} granularity="hour" unit="°C" height={220} type="area" /></Section>
                <Section title="Soil moisture — 24 h"><TrendChart data={d.trend.soil_moisture} series={s1} granularity="hour" unit="%" height={220} type="area" /></Section>
              </div>
              <div className="mt-6 grid gap-6 lg:grid-cols-2">
                <Section title="Recent alerts">
                  <TableWrap><thead><tr><th className="th">Severity</th><th className="th">Message</th><th className="th">When</th></tr></thead>
                    <tbody className="divide-y divide-slate-100">{d.alerts.map((a) => <tr key={a.id}><td className="td"><SeverityBadge severity={a.severity} /></td><td className="td !whitespace-normal">{a.message}</td><td className="td text-slate-500">{dateTime(a.timestamp)}</td></tr>)}</tbody></TableWrap>
                </Section>
                <Section title="Recent irrigation">
                  <TableWrap><thead><tr><th className="th">Started</th><th className="th">Duration</th><th className="th">Water</th><th className="th">Status</th></tr></thead>
                    <tbody className="divide-y divide-slate-100">{d.irrigation.map((r) => <tr key={r.id}><td className="td">{dateTime(r.timestamp)}</td><td className="td">{r.duration} min</td><td className="td">{num(r.water_used, 0)} L</td><td className="td capitalize">{r.status}</td></tr>)}</tbody></TableWrap>
                </Section>
              </div>
            </>
          );
        }}
      </Async>
    </>
  );
}
