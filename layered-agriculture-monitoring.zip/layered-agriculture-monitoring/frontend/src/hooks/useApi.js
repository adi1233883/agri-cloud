import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../services/api';
import { useFarm } from '../context/FarmContext';

/** GET a path; re-fetches when the path or farm changes. `interval` (ms) polls silently in the background. */
export function useApi(path, { interval = 0, enabled = true } = {}) {
  const { farmId } = useFarm();
  const [state, setState] = useState({ data: null, error: null, loading: enabled });
  const alive = useRef(true);

  const load = useCallback(async (silent = false) => {
    if (!enabled || !path) return;
    if (!silent) setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const data = await api.get(path);
      if (alive.current) setState({ data, error: null, loading: false });
    } catch (e) {
      if (alive.current) setState((s) => ({ data: silent ? s.data : null, error: silent ? s.error : e.message, loading: false }));
    }
  }, [path, enabled, farmId]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    alive.current = true;
    load();
    const t = interval ? setInterval(() => load(true), interval) : null;
    return () => { alive.current = false; if (t) clearInterval(t); };
  }, [load, interval]);

  return { ...state, reload: () => load(false), refresh: () => load(true) };
}
