import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { FarmProvider } from './context/FarmContext';
import Layout from './components/Layout';
import { Spinner } from './components/ui';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Layers from './pages/Layers';
import LayerDetail from './pages/LayerDetail';
import Live from './pages/Live';
import Analytics from './pages/Analytics';
import Irrigation from './pages/Irrigation';
import CropHealth from './pages/CropHealth';
import Alerts from './pages/Alerts';
import Reports from './pages/Reports';
import Settings from './pages/Settings';

function Protected({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <Spinner label="Starting up…" />;
  return user ? <FarmProvider>{children}</FarmProvider> : <Navigate to="/login" replace />;
}

export default function App() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />
      <Route element={<Protected><Layout /></Protected>}>
        <Route index element={<Dashboard />} />
        <Route path="layers" element={<Layers />} />
        <Route path="layers/:id" element={<LayerDetail />} />
        <Route path="live" element={<Live />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="irrigation" element={<Irrigation />} />
        <Route path="crop-health" element={<CropHealth />} />
        <Route path="alerts" element={<Alerts />} />
        <Route path="reports" element={<Reports />} />
        <Route path="settings" element={<Settings />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
