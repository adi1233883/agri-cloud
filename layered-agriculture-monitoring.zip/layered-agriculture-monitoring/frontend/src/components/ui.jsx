import { AlertTriangle, ArrowDownRight, ArrowUpRight, Inbox, Loader2, Minus, X } from 'lucide-react';
import { Area, AreaChart, ResponsiveContainer } from 'recharts';
import { CONDITION_STYLE, SEVERITY_LABEL, SEVERITY_STYLE, num } from '../utils/format';

export function Spinner({ label = 'Loading…' }) {
  return (
    <div className="flex items-center justify-center gap-3 py-16 text-slate-500" role="status">
      <Loader2 className="h-5 w-5 animate-spin text-leaf-600" /> <span className="text-sm">{label}</span>
    </div>
  );
}

export function ErrorState({ message, onRetry }) {
  return (
    <div className="card flex flex-col items-center gap-3 px-6 py-12 text-center" role="alert">
      <div className="rounded-full bg-rose-50 p-3 text-rose-600"><AlertTriangle className="h-6 w-6" /></div>
      <h3 className="text-lg font-bold">Something went wrong</h3>
      <p className="max-w-md text-sm text-slate-500">{message}</p>
      {onRetry && <button className="btn-primary" onClick={onRetry}>Try again</button>}
    </div>
  );
}

export function EmptyState({ title = 'Nothing here yet', text }) {
  return (
    <div className="flex flex-col items-center gap-2 px-6 py-12 text-center">
      <div className="rounded-full bg-leaf-50 p-3 text-leaf-600"><Inbox className="h-6 w-6" /></div>
      <h3 className="font-bold text-forest">{title}</h3>
      {text && <p className="max-w-sm text-sm text-slate-500">{text}</p>}
    </div>
  );
}

/** Wrap a useApi result: shows spinner / error / children(data). */
export function Async({ state, children, empty }) {
  if (state.loading && !state.data) return <Spinner />;
  if (state.error && !state.data) return <ErrorState message={state.error} onRetry={state.reload} />;
  if (!state.data) return null;
  if (empty?.(state.data)) return <div className="card"><EmptyState title={empty.title} text={empty.text} /></div>;
  return children(state.data);
}

export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-bold sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  );
}

export function Section({ title, subtitle, action, children, className = '' }) {
  return (
    <section className={`card p-5 ${className}`}>
      {(title || action) && (
        <div className="mb-4 flex flex-wrap items-start justify-between gap-2">
          <div>
            <h2 className="text-lg font-bold">{title}</h2>
            {subtitle && <p className="text-sm text-slate-500">{subtitle}</p>}
          </div>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export const ConditionBadge = ({ condition }) => (
  <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ${CONDITION_STYLE[condition] || 'bg-slate-100 text-slate-600'}`}>{condition}</span>
);
export const SeverityBadge = ({ severity }) => (
  <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ${SEVERITY_STYLE[severity]}`}>{SEVERITY_LABEL[severity]}</span>
);

export function LiveBadge({ updatedAt, paused }) {
  return (
    <span className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-semibold ${paused ? 'bg-slate-100 text-slate-600' : 'bg-leaf-100 text-leaf-800'}`}>
      <span className={`h-2 w-2 rounded-full ${paused ? 'bg-slate-400' : 'live-dot bg-leaf-500'}`} />
      {paused ? 'Paused' : 'Live Data'}
      {updatedAt && <span className="font-normal text-slate-500">· {new Date(updatedAt).toLocaleTimeString('en-IN')}</span>}
    </span>
  );
}

export function RangeFilter({ value, onChange }) {
  const opts = [['today', 'Today'], ['7d', 'Last 7 days'], ['30d', 'Last 30 days']];
  return (
    <div className="inline-flex rounded-xl border border-slate-200 bg-white p-1" role="group" aria-label="Date range">
      {opts.map(([k, l]) => (
        <button key={k} onClick={() => onChange(k)} aria-pressed={value === k}
          className={`rounded-lg px-3 py-1.5 text-sm font-semibold transition ${value === k ? 'bg-forest text-white' : 'text-slate-600 hover:bg-leaf-50'}`}>{l}</button>
      ))}
    </div>
  );
}

export function Tabs({ tabs, value, onChange }) {
  return (
    <div className="-mx-1 flex gap-1 overflow-x-auto px-1 pb-1" role="tablist">
      {tabs.map(([k, l]) => (
        <button key={k} role="tab" aria-selected={value === k} onClick={() => onChange(k)}
          className={`whitespace-nowrap rounded-full px-3.5 py-1.5 text-sm font-semibold transition ${value === k ? 'bg-leaf-600 text-white' : 'bg-leaf-50 text-leaf-800 hover:bg-leaf-100'}`}>{l}</button>
      ))}
    </div>
  );
}

export function Sparkline({ data, color = '#34975c' }) {
  const pts = (data || []).map((v, i) => ({ i, v })).filter((p) => p.v != null);
  if (pts.length < 2) return <div className="h-10" />;
  const id = `sp${color.replace('#', '')}`;
  return (
    <div className="h-10 w-full" aria-hidden="true">
      <ResponsiveContainer>
        <AreaChart data={pts} margin={{ top: 2, bottom: 2, left: 0, right: 0 }}>
          <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity={0.35} /><stop offset="100%" stopColor={color} stopOpacity={0} /></linearGradient></defs>
          <Area type="monotone" dataKey="v" stroke={color} strokeWidth={2} fill={`url(#${id})`} isAnimationActive={false} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

/** tone: 'upGood' (up = green), 'upBad' (up = amber), 'neutral' */
export function KpiCard({ icon: Icon, label, value, unit, change, tone = 'neutral', spark, note = 'from yesterday', decimals = 1, accent = 'bg-leaf-100 text-leaf-700' }) {
  const up = change > 0, flat = change == null || change === 0;
  const good = tone === 'upGood' ? up : tone === 'upBad' ? !up : null;
  const color = flat || good === null ? 'text-slate-500' : good ? 'text-leaf-600' : 'text-rose-600';
  const Arrow = flat ? Minus : up ? ArrowUpRight : ArrowDownRight;
  return (
    <div className="card fade-up flex flex-col gap-3 p-4">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-slate-500">{label}</span>
        <span className={`rounded-lg p-2 ${accent}`}><Icon className="h-4 w-4" /></span>
      </div>
      <div className="flex items-baseline gap-1">
        <span className="font-display text-3xl font-bold text-forest">{num(value, decimals)}</span>
        <span className="text-sm font-medium text-slate-500">{unit}</span>
      </div>
      <div className={`flex items-center gap-1 text-xs font-semibold ${color}`}>
        <Arrow className="h-3.5 w-3.5" />
        {change == null ? 'No earlier data' : `${Math.abs(change)}% ${up ? 'up' : change < 0 ? 'down' : 'no change'}`}
        {change != null && <span className="font-normal text-slate-400">{note}</span>}
      </div>
      {spark && <Sparkline data={spark} color={flat || good === null || good ? '#34975c' : '#d64545'} />}
    </div>
  );
}

export function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-forest/50 p-0 sm:items-center sm:p-4" onClick={onClose} role="dialog" aria-modal="true" aria-label={title}>
      <div className="card max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-b-none p-5 sm:rounded-b-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-bold">{title}</h3>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100" aria-label="Close"><X className="h-5 w-5" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

/** Circular score indicator. */
export function HealthRing({ score, size = 96 }) {
  const s = Math.max(0, Math.min(100, Number(score) || 0));
  const r = 40, c = 2 * Math.PI * r;
  const color = s >= 85 ? '#34975c' : s >= 70 ? '#e0a21a' : '#d64545';
  return (
    <div className="relative" style={{ width: size, height: size }} role="img" aria-label={`Health score ${s} percent`}>
      <svg viewBox="0 0 100 100" className="-rotate-90">
        <circle cx="50" cy="50" r={r} fill="none" stroke="#e8efe9" strokeWidth="10" />
        <circle cx="50" cy="50" r={r} fill="none" stroke={color} strokeWidth="10" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - s / 100)} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-xl font-bold text-forest">{Math.round(s)}%</span>
      </div>
    </div>
  );
}

export const TableWrap = ({ children }) => <div className="overflow-x-auto rounded-xl border border-slate-100"><table className="min-w-full divide-y divide-slate-100">{children}</table></div>;
