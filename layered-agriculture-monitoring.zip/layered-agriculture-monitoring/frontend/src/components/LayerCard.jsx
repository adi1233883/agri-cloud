import { Link } from 'react-router-dom';
import { Droplets, Thermometer, Waves, FlaskConical, ArrowRight } from 'lucide-react';
import { ConditionBadge } from './ui';
import { layerColor, num, shortLayer, zoneName } from '../utils/format';

const Stat = ({ icon: Icon, label, value, unit }) => (
  <div className="rounded-xl bg-mist px-3 py-2.5">
    <div className="flex items-center gap-1.5 text-xs text-slate-500"><Icon className="h-3.5 w-3.5" />{label}</div>
    <div className="mt-0.5 font-display text-lg font-bold text-forest">{value}<span className="ml-0.5 text-xs font-medium text-slate-500">{unit}</span></div>
  </div>
);

export default function LayerCard({ layer }) {
  const v = layer.values || {};
  return (
    <article className="card fade-up overflow-hidden">
      <div className="h-1.5" style={{ background: layerColor(layer.id) }} />
      <div className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-xs font-semibold uppercase tracking-wide" style={{ color: layerColor(layer.id) }}>{shortLayer(layer.layer_name)}</div>
            <h3 className="text-xl font-bold">{zoneName(layer.layer_name)}</h3>
            <p className="text-sm text-slate-500">{layer.crop_type} · {num(layer.area, 1)} ha</p>
          </div>
          <ConditionBadge condition={layer.condition} />
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2.5">
          <Stat icon={Thermometer} label="Temperature" value={num(v.temperature)} unit="°C" />
          <Stat icon={Droplets} label="Humidity" value={num(v.humidity, 0)} unit="%" />
          <Stat icon={Waves} label="Soil Moisture" value={num(v.soil_moisture)} unit="%" />
          <Stat icon={FlaskConical} label="Soil pH" value={num(v.soil_ph, 2)} />
        </div>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-xs text-slate-500">{layer.irrigating ? '💧 Irrigating now' : layer.activeAlerts ? `${layer.activeAlerts} active alert${layer.activeAlerts > 1 ? 's' : ''}` : 'No active alerts'}</span>
          <Link to={`/layers/${layer.id}`} className="btn-ghost !py-1.5">View Details <ArrowRight className="h-4 w-4" /></Link>
        </div>
      </div>
    </article>
  );
}
