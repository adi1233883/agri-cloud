import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { Activity, BarChart3, Bell, ChevronDown, Droplets, FileText, Layers, LayoutDashboard, LogOut, Menu, Settings, Sprout, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useFarm } from '../context/FarmContext';
import { useApi } from '../hooks/useApi';
import { LAYER_COLORS } from '../utils/format';

const NAV = [
  ['/', 'Dashboard', LayoutDashboard], ['/layers', 'Farm Layers', Layers], ['/live', 'Live Monitoring', Activity],
  ['/analytics', 'Analytics', BarChart3], ['/irrigation', 'Irrigation', Droplets], ['/crop-health', 'Crop Health', Sprout],
  ['/alerts', 'Alerts', Bell], ['/reports', 'Reports', FileText], ['/settings', 'Settings', Settings],
];

export function Logo({ light = false }) {
  return (
    <div className="flex items-center gap-2.5">
      <svg viewBox="0 0 32 32" className="h-8 w-8" aria-hidden="true">
        {LAYER_COLORS.slice(0, 4).map((c, i) => <rect key={c} x="3" y={4 + i * 6.5} width="26" height="5" rx="2.5" fill={c} />)}
      </svg>
      <div className="leading-tight">
        <div className={`font-display text-lg font-bold ${light ? 'text-white' : 'text-forest'}`}>AgriLayer</div>
        <div className={`text-[10px] font-semibold uppercase tracking-[0.14em] ${light ? 'text-leaf-300' : 'text-leaf-600'}`}>Agriculture Monitoring</div>
      </div>
    </div>
  );
}

function Sidebar({ onNavigate }) {
  const { user } = useAuth();
  return (
    <nav className="flex h-full flex-col gap-1 p-4" aria-label="Main">
      <div className="mb-6 px-2 pt-1"><Logo light /></div>
      {NAV.map(([to, label, Icon]) => (
        <NavLink key={to} to={to} end={to === '/'} onClick={onNavigate}
          className={({ isActive }) => `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition ${isActive ? 'bg-leaf-600 text-white' : 'text-leaf-100/80 hover:bg-white/10 hover:text-white'}`}>
          <Icon className="h-[18px] w-[18px]" /> {label}
        </NavLink>
      ))}
      <div className="mt-auto rounded-xl bg-white/5 p-3 text-xs text-leaf-200">
        <div className="font-semibold text-white">Signed in as {user?.role}</div>
        <div className="mt-0.5 truncate">{user?.email}</div>
      </div>
    </nav>
  );
}

export default function Layout() {
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const { user, logout } = useAuth();
  const { farms, farmId, select } = useFarm();
  const loc = useLocation();
  const alerts = useApi('/alerts?status=active', { interval: 30000 });
  const count = alerts.data?.length ?? 0;

  useEffect(() => { setOpen(false); setMenu(false); window.scrollTo(0, 0); }, [loc.pathname]);

  return (
    <div className="min-h-screen lg:pl-64">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 bg-forest lg:block"><Sidebar /></aside>
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-forest/60" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 bg-forest shadow-xl">
            <button className="absolute right-3 top-3 rounded-lg p-2 text-white" onClick={() => setOpen(false)} aria-label="Close menu"><X className="h-5 w-5" /></button>
            <Sidebar onNavigate={() => setOpen(false)} />
          </aside>
        </div>
      )}

      <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-slate-200/70 bg-white/85 px-4 py-3 backdrop-blur sm:px-6">
        <button className="rounded-lg p-2 text-forest hover:bg-leaf-50 lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu"><Menu className="h-5 w-5" /></button>
        <div className="lg:hidden"><Logo /></div>
        <div className="ml-auto flex items-center gap-2 sm:gap-3">
          <label className="sr-only" htmlFor="farm">Farm</label>
          <select id="farm" value={farmId ?? ''} onChange={(e) => select(Number(e.target.value))} className="input !w-auto max-w-[9.5rem] !py-2 font-semibold sm:max-w-none">
            {farms.map((f) => <option key={f.id} value={f.id}>{f.farm_name}</option>)}
          </select>
          <NavLink to="/alerts" className="relative rounded-xl border border-slate-200 bg-white p-2.5 text-slate-600 hover:bg-leaf-50" aria-label={`Notifications: ${count} active alerts`}>
            <Bell className="h-[18px] w-[18px]" />
            {count > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">{count > 99 ? '99+' : count}</span>}
          </NavLink>
          <div className="relative">
            <button onClick={() => setMenu((m) => !m)} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white py-1.5 pl-1.5 pr-2.5 hover:bg-leaf-50" aria-haspopup="menu" aria-expanded={menu}>
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-leaf-600 text-sm font-bold text-white">{(user?.name || '?')[0].toUpperCase()}</span>
              <span className="hidden text-left leading-tight sm:block"><span className="block text-sm font-semibold text-forest">{user?.name}</span><span className="block text-xs capitalize text-slate-500">{user?.role}</span></span>
              <ChevronDown className="h-4 w-4 text-slate-400" />
            </button>
            {menu && (
              <div className="card absolute right-0 mt-2 w-56 p-1.5" role="menu">
                <div className="px-3 py-2 text-xs text-slate-500"><div className="truncate font-semibold text-forest">{user?.email}</div><div className="capitalize">{user?.role} account</div></div>
                <button className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold text-rose-600 hover:bg-rose-50" onClick={logout} role="menuitem"><LogOut className="h-4 w-4" /> Log out</button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1400px] p-4 sm:p-6"><Outlet /></main>
    </div>
  );
}
