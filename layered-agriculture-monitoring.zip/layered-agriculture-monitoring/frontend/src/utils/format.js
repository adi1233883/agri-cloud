export const LAYER_COLORS = ['#34975c', '#e0a21a', '#1f7a8c', '#8a5a2b', '#6b7fd6', '#c0568a'];
export const FARM_COLOR = '#0f2e22';
export const layerColor = (id) => LAYER_COLORS[(Number(id) - 1) % LAYER_COLORS.length];
export const layerKey = (id) => `L${id}`;
export const shortLayer = (name = '') => name.split('—')[0].trim();
export const zoneName = (name = '') => (name.split('—')[1] || name).trim();

export const METRICS = {
  temperature: { label: 'Temperature', unit: '°C', decimals: 1 },
  humidity: { label: 'Humidity', unit: '%', decimals: 1 },
  soil_moisture: { label: 'Soil Moisture', unit: '%', decimals: 1 },
  soil_ph: { label: 'Soil pH', unit: 'pH', decimals: 2 },
  light: { label: 'Light', unit: 'lux', decimals: 0 },
  water_level: { label: 'Water Tank', unit: '%', decimals: 1 },
  co2: { label: 'CO₂', unit: 'ppm', decimals: 0 },
  rainfall: { label: 'Rainfall', unit: 'mm/h', decimals: 1 },
  water_usage: { label: 'Water Usage', unit: 'L', decimals: 0 },
  crop_health: { label: 'Crop Health', unit: '%', decimals: 1 },
};

export const num = (v, d = 1) => (v == null || Number.isNaN(Number(v)) ? '—' : Number(v).toLocaleString('en-IN', { minimumFractionDigits: d, maximumFractionDigits: d }));
export const fmtMetric = (key, v) => num(v, METRICS[key]?.decimals ?? 1);

export const timeAgo = (iso) => {
  if (!iso) return '—';
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return `${Math.floor(s / 86400)} d ago`;
};
export const dateTime = (iso) => (iso ? new Date(iso).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—');
export const clock = (iso) => (iso ? new Date(iso).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—');

export function tickLabel(iso, granularity) {
  const d = new Date(iso);
  if (granularity === 'hour') return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false });
  if (granularity === '6h') return d.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', hour12: false });
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
}

export const CONDITION_STYLE = {
  Healthy: 'bg-leaf-100 text-leaf-800',
  'Needs Irrigation': 'bg-amber-100 text-amber-700',
  Attention: 'bg-amber-100 text-amber-700',
  Critical: 'bg-rose-100 text-rose-700',
};
export const SEVERITY_STYLE = {
  critical: 'bg-rose-100 text-rose-700',
  warning: 'bg-amber-100 text-amber-700',
  info: 'bg-sky-50 text-sky-700',
  good: 'bg-leaf-100 text-leaf-800',
};
export const SEVERITY_LABEL = { critical: 'Critical', warning: 'Warning', info: 'Informational', good: 'All clear' };
