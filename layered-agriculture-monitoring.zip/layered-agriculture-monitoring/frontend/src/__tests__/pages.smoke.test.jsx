// Smoke test: renders every page against a RUNNING backend (demo mode) and checks it loads without errors.
//   1) cd backend && npm start     2) cd frontend && npm test
import { afterEach, beforeAll, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import App from '../App.jsx';
import { AuthProvider } from '../context/AuthContext.jsx';

class RO { observe() {} unobserve() {} disconnect() {} }
globalThis.ResizeObserver = RO;
window.scrollTo = () => {};
window.print = () => {};
vi.spyOn(console, 'warn').mockImplementation(() => {});
vi.spyOn(console, 'error').mockImplementation(() => {});

const API = import.meta.env.VITE_API_URL;
const PAGES = [
  ['/', /Green Valley Farm/],
  ['/layers', /Farm Layers/],
  ['/layers/2', /Fruit Zone/],
  ['/live', /Live Monitoring/],
  ['/analytics', /Descriptive analytics/i],
  ['/irrigation', /Simulated irrigation control/],
  ['/crop-health', /Crop Health/],
  ['/alerts', /Alerts/],
  ['/reports', /Agricultural Report/],
  ['/settings', /Alert thresholds/],
];

beforeAll(async () => {
  const res = await fetch(`${API}/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'admin@agri.demo', password: 'Admin@123' }) });
  expect(res.ok).toBe(true);
  localStorage.setItem('agri_demo_token', (await res.json()).token);
});
afterEach(cleanup);

describe('pages render with live API data', () => {
  for (const [path, heading] of PAGES) {
    it(path, async () => {
      render(<MemoryRouter initialEntries={[path]}><AuthProvider><App /></AuthProvider></MemoryRouter>);
      await waitFor(() => expect(screen.getAllByText(heading).length).toBeGreaterThan(0), { timeout: 20000 });
      expect(screen.queryByText('Something went wrong')).toBeNull();
    });
  }
  it('login page shown when signed out', async () => {
    localStorage.clear();
    render(<MemoryRouter initialEntries={['/']}><AuthProvider><App /></AuthProvider></MemoryRouter>);
    await waitFor(() => expect(screen.getByText('Welcome back')).toBeTruthy());
    expect(await screen.findByText(/Demo accounts/)).toBeTruthy();
  });
});
